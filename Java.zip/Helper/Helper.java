package tecno.khaledtar.com.contolk.Helper;


import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.PowerManager;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import tecno.khaledtar.com.contolk.Snich.SinchService;

public class Helper {

    public static final String NAME = "Contact Person";

    public static final String EMAIL = "Email";

    public static final String ADDRESS = "Address";
    public static final String CITY = "CITY";
    public static final String POSTnr = "POSTnr.";
    public static final String PHONE_NUMBER = "Phone Number";

    public static final String COMPANY_NAME = "Company Name";

    public static final String STATUS = "Status";
    public static final String LANGUAGE = "Language";
    public static final String CVR = "CVRnr.";
    public static final String EAN = "EANnr.";
    public static final String Balance = "Balance";
    public static final String TOTALTIME ="Total Time" ;

    public static  String InvoiceHeader ;

    public static final String TOTALWORKINGHOURS = "Total working hours";
    public static final int SELECT_PICTURE = 2000;

    public static boolean isValidEmail(String email){
        if(email.contains("@")){
            return true;
        }
        return false;
    }

    public static void displayMessageToast(Context context, String displayMessage){
        Toast.makeText(context, displayMessage, Toast.LENGTH_LONG).show();
    }

    public static boolean checkInternetConnection(Context context){
        boolean connected = false;
        ConnectivityManager connectivityManager = (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        if(connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE).getState() == NetworkInfo.State.CONNECTED ||
                connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI).getState() == NetworkInfo.State.CONNECTED) {
            //we are connected to a network
            connected = true;
        }
        else connected = false;

        return  connected;
    }


    public static String getCurrentDateTime(){

        Calendar c = Calendar.getInstance();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
         String formattedDate = df.format(c.getTime());

         return formattedDate;
    }



}
