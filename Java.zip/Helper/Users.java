package tecno.khaledtar.com.contolk.Helper;

import com.google.firebase.database.Exclude;
import com.google.firebase.database.PropertyName;

/**
 * Created by Khaled on 16-Dec-17.
 */

public class Users {
    @PropertyName("uId")
    public String uId;
    @PropertyName("FullName")
    public String fullName;

    @PropertyName("PhoneNo")
    public String  phoneNo;

    @PropertyName("Address")
    public String address;

    @PropertyName("City")
    public String city;

    @PropertyName("Postnr")
    public String postnr;

    @PropertyName("Email")
    public String emailAddress;

    @PropertyName("SubscriptionDate")
    public String subscriptionDate;

    @PropertyName("Balance")
    public String balance;

    @PropertyName("AccessStatus")
    public String accessStatus;

    public void Users() {

    }




    public String getuId() {
        return this.uId;
    }
    @Exclude
    public String getEmail() {
        return this.emailAddress;
    }

    @Exclude
    public String getName() {return this.fullName;
    }
    @Exclude
    public String getAddress() {return this.address;}

    @Exclude
    public String getSubscriptionDate() {return this.subscriptionDate;}
    @Exclude
    public String getPhone() {return this.phoneNo;}
    @Exclude
    public String getCity() {return this.city;}
    @Exclude
    public String getPostnr() {return this.postnr;}

    @Exclude
    public String getAccessStatusStatus() {return this.accessStatus;}

    @Exclude
    public String getBalance() {return this.balance;}
    @Exclude
    public void setPhone(String phone) {
        this.phoneNo = phone;
    }
    @Exclude
    public void setCity(String city) {
        this.city = city;
    }
    @Exclude
    public void setPostnr(String postnr) {this.postnr = postnr;}

    @Exclude
    public void setSubscriptionDate(String date) {this.subscriptionDate = date;}


    @Exclude
    public void setId(String id) {
        this.uId = id;
    }

    @Exclude
    public void setBalance(String balance) {
        this.balance = balance;
    }

    @Exclude
    public void setname(String fullName) {
        this.fullName = fullName;
    }

    @Exclude
    public void setAddress(String address) {
        this.address = address;
    }

    @Exclude
    public void setEmail(String emailAddress) {
        this.emailAddress = emailAddress;
    }

    @Exclude
    public void setAccessStatus(String accessStatus) {
        this.accessStatus = accessStatus;
    }
}
