package tecno.khaledtar.com.contolk;


import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.Fragment;
import android.os.Bundle;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

import tecno.khaledtar.com.contolk.Helper.Helper;


/**
 * A simple {@link Fragment} subclass.
 */
public class Fragment_signUp extends Fragment {

  //  private static final String TAG = SignUpActivity.class.getSimpleName();

    private EditText emailInput;

    private EditText passwordInput,yearsExperianceInput;

    private TextView signUpText;
    private Spinner userType,languages;
    private TextView loginError;

    private FirebaseAuth mAuth;
    private RadioButton asTranslator,asUser;
    private String who,language;
    public Fragment_signUp() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
View view= inflater.inflate(R.layout.fragment_signup, container, false);


//cheacking internet
        ((ConTolk)getActivity().getApplication()).checkInternetConnection(getActivity());


        mAuth = ((ConTolk)getActivity().getApplication()).getFirebaseAuth();
        ((ConTolk)getActivity().getApplication()).checkUserType(getActivity());

        loginError = (TextView)view.findViewById(R.id.login_error1);

        emailInput = (EditText) view.findViewById(R.id.email1);
        passwordInput = (EditText)view.findViewById(R.id.password1);
        yearsExperianceInput = (EditText)view.findViewById(R.id.yearsExperiance);

        // my addition

        userType=(Spinner) view.findViewById(R.id.usertype1);
        languages=(Spinner) view.findViewById(R.id.languages);

 signUpText = (TextView)view.findViewById(R.id.register1);
        signUpText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Fragment_login fragment = new  Fragment_login();
                FragmentManager fm =getFragmentManager();
                FragmentTransaction ft=fm.beginTransaction();
                ft.replace(R.id.fragmentMain,fragment);
                ft.commit();
            }
        });

        final Button signUpButton = (Button)view.findViewById(R.id.signUp_button);
        signUpButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                who=userType.getSelectedItem().toString();
                language=languages.getSelectedItem().toString();
                String enteredEmail = emailInput.getText().toString().trim();
                String enteredPassword = passwordInput.getText().toString().trim();
                String experiance = yearsExperianceInput.getText().toString().trim();


                if(TextUtils.isEmpty(enteredEmail) || TextUtils.isEmpty(enteredPassword)){
                    Helper.displayMessageToast(getActivity(), "Login fields must be filled");
                    return;
                }
                if(!Helper.isValidEmail(enteredEmail)){
                    Helper.displayMessageToast(getActivity(), "Invalidate email entered");
                    return;
                }

                ((ConTolk)getActivity().getApplication()).createNewUser(getActivity(), enteredEmail.trim(), enteredPassword.trim(),who,language,experiance, loginError);



            }
        });
        return view;
    }

    @Override
    public void onPause() {
        super.onPause();

        ((ConTolk)getActivity().getApplication()).getFirebaseAuth().signOut();
        if (((ConTolk)getActivity().getApplication()).getFirebaseAuth() != null)
            ((ConTolk)getActivity().getApplication()).getFirebaseAuth().removeAuthStateListener(((ConTolk)getActivity().getApplication()).mAuthListener);
    }
}
