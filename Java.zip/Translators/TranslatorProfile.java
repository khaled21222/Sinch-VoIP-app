package tecno.khaledtar.com.contolk.Translators;

public class TranslatorProfile {

    private String header;

    private String profileContent;

    public TranslatorProfile(String header, String profileContent) {
        this.header = header;
        this.profileContent = profileContent;
    }

    public String getHeader() {
        return header;
    }

    public String getProfileContent() {
        return profileContent;
    }
}
