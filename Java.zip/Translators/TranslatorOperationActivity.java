package tecno.khaledtar.com.contolk.Translators;

import android.app.ActivityManager;

import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.util.Log;
import android.view.MenuItem;
import android.widget.Toast;


import com.crashlytics.android.Crashlytics;
import com.sinch.android.rtc.SinchError;

import io.fabric.sdk.android.Fabric;
import tecno.khaledtar.com.contolk.ConTolk;
import tecno.khaledtar.com.contolk.R;
import tecno.khaledtar.com.contolk.Snich.BaseActivity;
import tecno.khaledtar.com.contolk.Snich.SinchService;
import tecno.khaledtar.com.contolk.WakeUpDeviceRecevier;

public class TranslatorOperationActivity extends BaseActivity implements SinchService.StartFailedListener  {

    private FragmentManager fm;
    private FragmentTransaction ft ;
    private ProgressDialog mSpinner;
    String translatorEmail;

    Intent snichServiceIntent;
    SinchService sinchService;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {

            fm =getSupportFragmentManager();
            ft=fm.beginTransaction();
            switch (item.getItemId()) {
                case R.id.navigation_ChangeStatus_translator:
                    Fragment_TranslatorsStatusUpdate fragment1 = new Fragment_TranslatorsStatusUpdate();
                    ft.replace(R.id.fragment_translator,fragment1);
                    ft.commit();
                    return true;

                case R.id.navigation_profile_translator:
                    TranslatorProfileFragment fragment2 = new TranslatorProfileFragment();
                    ft.replace(R.id.fragment_translator,fragment2);
                    ft.commit();
                    return true;

                case R.id.navigation_settings_translator:
                    Fragment_Translators_Settings fragment3 = new Fragment_Translators_Settings();
                    ft.replace(R.id.fragment_translator,fragment3);
                    ft.commit();
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Fabric.with(this, new Crashlytics());
        logUser();
        setContentView(R.layout.activity_translator_operation);

       FragmentManager fm =getSupportFragmentManager();
        FragmentTransaction ft=fm.beginTransaction();
        ft.replace(R.id.fragment_translator,new Fragment_TranslatorsStatusUpdate()).commit();

  /*      snichServiceIntent=new Intent(this, SinchService.class);
        sinchService = new SinchService(this);

        if (!isMyServiceRunning(SinchService.class)) {
            startService(snichServiceIntent);
        }  */



        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigationTranslators);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }

    private boolean isMyServiceRunning(Class<?> serviceClass) {
        ActivityManager manager = (ActivityManager) getSystemService(Context.ACTIVITY_SERVICE);
        for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(Integer.MAX_VALUE)) {
            if (serviceClass.getName().equals(service.service.getClassName())) {
                Log.i ("isMyServiceRunning?", true+"");
                return true;
            }
        }
        Log.i ("isMyServiceRunning?", false+"");
        return false;
    }


    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }

    @Override
    protected void onServiceConnected() {
        getSinchServiceInterface().setStartListener(this);
    }

    @Override
    protected void onPause() {
        if (mSpinner != null) {
            mSpinner.dismiss();
        }
        super.onPause();
    }

    @Override
    public void onStartFailed(SinchError error) {
        Toast.makeText(this, error.toString(), Toast.LENGTH_LONG).show();
        if (mSpinner != null) {
            mSpinner.dismiss();
        }
    }

    @Override
    public void onStarted() {

    }






    public void showSpinner() {
        mSpinner = new ProgressDialog(this);
        mSpinner.setTitle("Logging in");
        mSpinner.setMessage("Please wait...");
        mSpinner.show();
    }




    @Override
    protected void onDestroy() {

   /*     if(((ConTolk)this.getApplication()).getFirebaseAuth().getCurrentUser()!=null){
        stopService(snichServiceIntent);
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            Intent broadcastIntent = new Intent(this,WakeUpDeviceRecevier.class);
        broadcastIntent.putExtra("email_key",((ConTolk)this.getApplication()).getFirebaseAuth().getCurrentUser().getEmail() );
        sendBroadcast(broadcastIntent);}  */

        super.onDestroy();

    }

    private void logUser() {
        // TODO: Use the current user's information
        // You can call any combination of these three methods
        Crashlytics.setUserEmail(((ConTolk)this.getApplication()).getFirebaseAuth().getCurrentUser().getEmail());
        Crashlytics.setUserName("User is translator");
    }
}
