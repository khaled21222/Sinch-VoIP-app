package tecno.khaledtar.com.contolk.Translators;


import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import tecno.khaledtar.com.contolk.Customers.CustomerOperationsActivity;
import tecno.khaledtar.com.contolk.Firebase.FirebaseDatabaseHelper;
import tecno.khaledtar.com.contolk.MainActivity;
import tecno.khaledtar.com.contolk.R;
import tecno.khaledtar.com.contolk.ConTolk;


/**
 * A simple {@link Fragment} subclass.
 */
public class Fragment_TranslatorsStatusUpdate extends Fragment {
    ImageView arrow1,arrow2;
    FirebaseDatabaseHelper firebaseDatabaseHelper;
    String status;

    public Fragment_TranslatorsStatusUpdate() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
       View view=inflater.inflate(R.layout.fragment_fragment__translators_status_update, container, false);

       getActivity().setTitle("Update Translator Status");

        //check if user alive
        ((ConTolk)getActivity().getApplication()).checkIfUserAlive(getActivity());

        final Spinner translatorStatus = (Spinner) view.findViewById(R.id.translator_status_spinner);
       final Button update = (Button) view.findViewById(R.id.updateTrans_b);
        arrow1=(ImageView) view.findViewById(R.id.arrow1);
         arrow2=(ImageView) view.findViewById(R.id.arrow2);


        firebaseDatabaseHelper = new FirebaseDatabaseHelper();


        Animation animation = new AlphaAnimation(1, 0);
        animation.setDuration(1000);
        animation.setInterpolator(new LinearInterpolator());
        animation.setRepeatCount(Animation.INFINITE);
        animation.setRepeatMode(Animation.REVERSE);
        arrow1.startAnimation(animation);



        // fill spinner
        String currentstatus=((ConTolk)getActivity().getApplication()).readFrom_sharedprefernce(getActivity(),"translatorStatus_key");
        if (currentstatus!=null){
        if (currentstatus.equals("Available"))
        translatorStatus.setSelection(1);
        else
        translatorStatus.setSelection(0);}




        translatorStatus.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            int check = 0;
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                if(++check > 1) {

                    arrow1.clearAnimation();
                    Animation animation = new AlphaAnimation(1, 0);
                    animation.setDuration(1000);
                    animation.setInterpolator(new LinearInterpolator());
                    animation.setRepeatCount(Animation.INFINITE);
                    animation.setRepeatMode(Animation.REVERSE);
                    arrow2.startAnimation(animation);
                }


            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }


        });







        update.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                arrow2.clearAnimation();
                arrow1.setVisibility(View.INVISIBLE);
                arrow2.setVisibility(View.INVISIBLE);
               status = translatorStatus.getSelectedItem().toString();

                ((ConTolk)getActivity().getApplication()).saveUserAccessInfo_sharedprefernce(getActivity(),"translatorStatus_key",status);
                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();

                  String id = user.getUid();
                  String language=((ConTolk)getActivity().getApplication()).readFrom_sharedprefernce(getActivity(),"language_key");

                    firebaseDatabaseHelper.updateTranslatorStatus(id,language, status);

                    Toast.makeText(getActivity(),"Your status was updated",Toast.LENGTH_LONG).show();

                    if (status.equals("Available"))
                        loginClicked();
                    else
                    {  ((TranslatorOperationActivity)getActivity()).getSinchServiceInterface().stopClient();
                   }

                }

        });
        return view;
    }


    private void loginClicked() {
        String userName = ((ConTolk)getActivity().getApplication()).getFirebaseAuth().getCurrentUser().getEmail();

        if (userName.isEmpty()) {
            Toast.makeText(getActivity(), "There is No username for Snich service", Toast.LENGTH_LONG).show();
            return;
        }

        if (!userName.equals(((TranslatorOperationActivity)getActivity()).getSinchServiceInterface().getUserName())) {
            ((TranslatorOperationActivity)getActivity()).getSinchServiceInterface().stopClient();
        }

        if (!((TranslatorOperationActivity)getActivity()).getSinchServiceInterface().isStarted()) {
            ((TranslatorOperationActivity)getActivity()).getSinchServiceInterface().startClient(userName);

        } else {
            // ((OnlineTranslatorsActivity)context).openPlaceCallActivity();
        }

    }


    @Override
    public void onDestroyView() {
        super.onDestroyView();

        if (((TranslatorOperationActivity)getActivity()).getSinchServiceInterface() != null && ((ConTolk)getActivity().getApplication()).firebaseAuth.getCurrentUser()==null ){
            ((TranslatorOperationActivity)getActivity()).getSinchServiceInterface().stopClient();

            getActivity().stopService(new Intent("tecno.khaledtar.com.contolk.Snich.SinchService").setPackage("tecno.khaledtar.com.contolk"));



            Toast.makeText(getActivity(),"You are OFFLINE",Toast.LENGTH_LONG).show();
        }

    }
}
