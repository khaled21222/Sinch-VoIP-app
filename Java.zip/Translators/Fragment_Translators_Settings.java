package tecno.khaledtar.com.contolk.Translators;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

import android.support.v4.app.Fragment;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;

import tecno.khaledtar.com.contolk.ConTolk;
import tecno.khaledtar.com.contolk.MainActivity;
import tecno.khaledtar.com.contolk.R;


public class Fragment_Translators_Settings extends Fragment {
    // TODO: Rename parameter arguments, choose names that match


  public Fragment_Translators_Settings() {
        // Required empty public constructor
    }




    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        getActivity().setTitle("Settings");


    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
     inflater.inflate(R.menu.translators_setting_menu, menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.menu_logout){

      logout();



            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void logout() {

        String currentstatus=((ConTolk)getActivity().getApplication()).readFrom_sharedprefernce(getActivity(),"translatorStatus_key");
        if (currentstatus!=null && currentstatus.equals("Available")){

            Toast.makeText(getActivity(),"Make your status UNAVAILABLE first",Toast.LENGTH_LONG).show();

        }
        else
        { ((ConTolk)getActivity().getApplication()).getFirebaseAuth().signOut();
            if (((ConTolk)getActivity().getApplication()).mAuthListener != null)
                ((ConTolk)getActivity().getApplication()).getFirebaseAuth().removeAuthStateListener(((ConTolk)getActivity().getApplication()).mAuthListener);

            Intent profileIntent = new Intent(getActivity(), MainActivity.class);
            startActivity(profileIntent);
            Toast.makeText(getActivity(),"The user is logged out",Toast.LENGTH_SHORT).show();
            getActivity().finish();}
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
         View view= inflater.inflate(R.layout.fragment_fragment__translators__settings, container, false);
        Button logout=(Button) view.findViewById(R.id.setting_logOut_button);
        Button contact=(Button) view.findViewById(R.id.setting_contactUs_button);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logout();
            }
        });

        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String[] TO = {"jacob_saxtoft@hotmail.com"};
                String[] CC = {"khaledtar.tecno@gmail.com"};
                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.setData(Uri.parse("mailto:"));
                emailIntent.setType("text/plain");


                emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
                emailIntent.putExtra(Intent.EXTRA_CC, CC);
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Your subject");
                emailIntent.putExtra(Intent.EXTRA_TEXT,"Sent from user ref: "+((ConTolk)getActivity().getApplication()).getFirebaseUserAuthenticateId());


                try {
                    startActivity(Intent.createChooser(emailIntent, "Send mail..."));
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(getActivity(),
                            "There is no email client installed.", Toast.LENGTH_SHORT).show();
                }

            }
        });

        return view;
    }







}
