package tecno.khaledtar.com.contolk.Translators;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.HashMap;
import java.util.Map;

import tecno.khaledtar.com.contolk.ConTolk;
import tecno.khaledtar.com.contolk.Firebase.FirebaseDatabaseHelper;
import tecno.khaledtar.com.contolk.Helper.Helper;
import tecno.khaledtar.com.contolk.MainActivity;
import tecno.khaledtar.com.contolk.R;

//import com.delaroystudios.firebaselogin.Firebase.FirebaseDatabaseHelper;
//import com.delaroystudios.firebaselogin.Firebase.FirebaseCustomerEntity;
//import com.delaroystudios.firebaselogin.Helper.Helper;

public class EditTranslatorProfileActivity extends AppCompatActivity {

    private static final String TAG = EditTranslatorProfileActivity.class.getSimpleName();

    private EditText editProfileName;

    private EditText editProfileAddress;

    private EditText editProfilePhoneNumber,editProfileProfile;

    private Spinner editProfileLanguage;
    private Spinner editProfileGender;




    private FirebaseAuth.AuthStateListener authStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_translator_profile);

        setTitle("Edit Profile Information");

        editProfileName = (EditText)findViewById(R.id.profile_name);
        editProfileAddress = (EditText)findViewById(R.id.profile_address);
        editProfileProfile = (EditText)findViewById(R.id.profile_profile);
        editProfilePhoneNumber = (EditText)findViewById(R.id.profile_phone);
        editProfileGender = (Spinner)findViewById(R.id.profile_gender);


        Button saveEditButton = (Button)findViewById(R.id.save_edit_button);
        saveEditButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String profileName = editProfileName.getText().toString().trim();
                String profileAddress = editProfileAddress.getText().toString().trim();
                String profilePhoneNumber = editProfilePhoneNumber.getText().toString().trim();
                String profileStatment = editProfileProfile.getText().toString().trim();
                String profileGender = editProfileGender.getSelectedItem().toString();
            //    String profileLanguage = ((ConTolk)EditTranslatorProfileActivity.this.getApplication()).readFrom_sharedprefernce(EditTranslatorProfileActivity.this,"language");
            //    String profilestatus = editProfileStatuse.getSelectedItem().toString();



                // update the user profile information in Firebase database.
                if(TextUtils.isEmpty(profileName) || TextUtils.isEmpty(profileAddress) || TextUtils.isEmpty(profilePhoneNumber)
                         ){
                    Helper.displayMessageToast(EditTranslatorProfileActivity.this, "All fields must be filled");
                    return;
                }

                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                if (user == null) {
                    Intent firebaseUserIntent = new Intent(EditTranslatorProfileActivity.this, MainActivity.class);
                    startActivity(firebaseUserIntent);
                    finish();
                } else {
                    //String userId = user.getProviderId();
                    String id = user.getUid();
                  //  String profileEmail = user.getEmail();


                    Map<String, Object> translatorProfile = new HashMap<String, Object>();

                    translatorProfile.put("FullName",profileName);
                    translatorProfile.put("PhoneNo",profilePhoneNumber);
                    translatorProfile.put("Address",profileAddress);
                    translatorProfile.put("Profile",profileStatment);
                    translatorProfile.put("Gender",profileGender);



                    FirebaseDatabaseHelper firebaseDatabaseHelper = new FirebaseDatabaseHelper();
                    firebaseDatabaseHelper.createTranslatorInFirebaseDatabase(id ,translatorProfile);

                    editProfileName.setText("");
                    editProfileAddress.setText("");
                    editProfilePhoneNumber.setText("");
                    editProfileProfile.setText("");

                    String firstTimeLogIn= ((ConTolk)EditTranslatorProfileActivity.this.getApplication()).readFrom_sharedprefernce(EditTranslatorProfileActivity.this,"firstTimeLogIn");

                   if (firstTimeLogIn.equals("true"))
                            ((ConTolk)EditTranslatorProfileActivity.this.getApplication()).saveUserAccessInfo_sharedprefernce(EditTranslatorProfileActivity.this,"firstTimeLogIn","false");

                            Intent i =new Intent(EditTranslatorProfileActivity.this,TranslatorOperationActivity.class);
                            startActivity(i);
                            finish();


                    Toast.makeText(EditTranslatorProfileActivity.this,"Profile information was updated",Toast.LENGTH_LONG).show();

                }
            }
        });
    }
}
