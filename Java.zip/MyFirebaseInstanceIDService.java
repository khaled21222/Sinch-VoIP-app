package tecno.khaledtar.com.contolk;

import com.google.firebase.iid.FirebaseInstanceIdService;

/**
 * Created by Khaled on 15-Feb-18.
 */

public class MyFirebaseInstanceIDService extends FirebaseInstanceIdService {

}
