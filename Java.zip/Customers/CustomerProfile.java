package tecno.khaledtar.com.contolk.Customers;

public class CustomerProfile {

    private String header;

    private String profileContent;

    public CustomerProfile(String header, String profileContent) {
        this.header = header;
        this.profileContent = profileContent;
    }

    public String getHeader() {
        return header;
    }

    public String getProfileContent() {
        return profileContent;
    }
}
