package tecno.khaledtar.com.contolk.Customers;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.Toast;

//import com.delaroystudios.firebaselogin.Firebase.FirebaseDatabaseHelper;
//import com.delaroystudios.firebaselogin.Firebase.FirebaseCustomerEntity;
//import com.delaroystudios.firebaselogin.Helper.Helper;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.util.HashMap;
import java.util.Map;

import tecno.khaledtar.com.contolk.Firebase.FirebaseDatabaseHelper;
import tecno.khaledtar.com.contolk.Helper.Helper;
import tecno.khaledtar.com.contolk.MainActivity;
import tecno.khaledtar.com.contolk.R;
import tecno.khaledtar.com.contolk.ConTolk;

public class EditCustomerProfileActivity extends AppCompatActivity {

    private static final String TAG = EditCustomerProfileActivity.class.getSimpleName();

    private EditText editProfileUserName;

    private EditText editProfileAddress;

    private EditText editProfilePhoneNumber;

    private EditText editProfileCVR,editProfileEmail,editProfileCompanyName,editProfileCompanyEAN;
    private Spinner editProfileCity,editProfilePostnr;



    private FirebaseAuth.AuthStateListener authStateListener;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_user_profile);

        setTitle("Edit Profile Information");

        editProfileUserName = (EditText)findViewById(R.id.user_name);
        editProfilePhoneNumber = (EditText)findViewById(R.id.profile_phone);

        editProfileCompanyName = (EditText)findViewById(R.id.nameOfCompany);
        editProfileCVR = (EditText)findViewById(R.id.cvtNo);
        editProfileCompanyEAN = (EditText)findViewById(R.id.EANnr);
        editProfileAddress = (EditText)findViewById(R.id.profile_address);
        editProfileCity = (Spinner)findViewById(R.id.address_city);
        editProfilePostnr = (Spinner)findViewById(R.id.address_postNo);


        Button saveEditButton = (Button)findViewById(R.id.save_edit_button);
        saveEditButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String profileName = editProfileUserName.getText().toString();
                String profileAddress = editProfileAddress.getText().toString();
                String profilePhoneNumber = editProfilePhoneNumber.getText().toString();
                String profileCVR = editProfileCVR.getText().toString();
                String profileEAN = editProfileCompanyEAN.getText().toString();
                String profileCompanyName = editProfileCompanyName.getText().toString();
                String profileCompanyCity = editProfileCity.getSelectedItem().toString();
                String profileCompanyPostnr = editProfilePostnr.getSelectedItem().toString();

                // update the user profile information in Firebase database.
                if(TextUtils.isEmpty(profileName) || TextUtils.isEmpty(profileAddress) || TextUtils.isEmpty(profilePhoneNumber) || TextUtils.isEmpty(profileCompanyPostnr)
                        || TextUtils.isEmpty(profileCVR) || TextUtils.isEmpty(profileCompanyName) || TextUtils.isEmpty(profileEAN) || TextUtils.isEmpty(profileCompanyName)){
                    Helper.displayMessageToast(EditCustomerProfileActivity.this, "All fields must be filled");
                    return;
                }

                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                if (user == null) {
                    Intent firebaseUserIntent = new Intent(EditCustomerProfileActivity.this, MainActivity.class);
                    startActivity(firebaseUserIntent);
                    finish();
                } else {
                   // String userId = user.getProviderId();
                    String id = user.getUid();


                    //my addition

                    Map<String, Object> userProfile = new HashMap<String, Object>();
                    userProfile.put("uId",id);
                    userProfile.put("FullName",profileName);
                    userProfile.put("PhoneNo",profilePhoneNumber);
                    userProfile.put("CompanyName",profileCompanyName);
                    userProfile.put("CVRnr",profileCVR);
                    userProfile.put("EANnr",profileEAN);
                    userProfile.put("Address",profileAddress);
                    userProfile.put("City",profileCompanyCity);
                    userProfile.put("Postnr",profileCompanyPostnr);



                    FirebaseDatabaseHelper firebaseDatabaseHelper = new FirebaseDatabaseHelper();
                    firebaseDatabaseHelper.createUserInFirebaseDatabase(id, userProfile);

                    editProfileUserName.setText("");
                    editProfileAddress.setText("");
                    editProfilePhoneNumber.setText("");
                    editProfileCVR.setText("");
                    editProfileCompanyName.setText("");
                    editProfileCompanyEAN.setText("");

                    String firstTimeLogIn= ((ConTolk)EditCustomerProfileActivity.this.getApplication()).readFrom_sharedprefernce(EditCustomerProfileActivity.this,"firstTimeLogIn");

                    if (firstTimeLogIn.equals("true"))
                        ((ConTolk)EditCustomerProfileActivity.this.getApplication()).saveUserAccessInfo_sharedprefernce(EditCustomerProfileActivity.this,"firstTimeLogIn","false");

                            Intent i =new Intent(EditCustomerProfileActivity.this,CustomerOperationsActivity.class);
                            startActivity(i);
                            finish();





                    Toast.makeText(EditCustomerProfileActivity.this,"Profile information was updated",Toast.LENGTH_LONG).show();

                }
            }
        });
    }
}
