package tecno.khaledtar.com.contolk.Customers;


import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;

import tecno.khaledtar.com.contolk.ConTolk;
import tecno.khaledtar.com.contolk.InvoicesListActivity;
import tecno.khaledtar.com.contolk.MainActivity;
import tecno.khaledtar.com.contolk.R;


/**
 * A simple {@link Fragment} subclass.
 */
public class Fragment_Customers_Settings extends Fragment {


    public Fragment_Customers_Settings() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        getActivity().setTitle("Settings");

        View view=inflater.inflate(R.layout.fragment_settings, container, false);

        Button transactionsList=(Button) view.findViewById(R.id.setting_transaction_button);
        Button logout=(Button) view.findViewById(R.id.setting_logOut_button);
        Button contact=(Button) view.findViewById(R.id.setting_contactUs_button);



        contact.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

                String[] TO = {"jacob_saxtoft@hotmail.com"};
                String[] CC = {"khaledtar.tecno@gmail.com"};
                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.setData(Uri.parse("mailto:"));
                emailIntent.setType("text/plain");


                emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
                emailIntent.putExtra(Intent.EXTRA_CC, CC);
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Your subject");
                emailIntent.putExtra(Intent.EXTRA_TEXT,"Sent from user ref: "+((ConTolk)getActivity().getApplication()).getFirebaseUserAuthenticateId());


                try {
                    startActivity(Intent.createChooser(emailIntent, "Send mail..."));
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(getActivity(),
                            "There is no email client installed.", Toast.LENGTH_SHORT).show();
                }

            }
        });

        transactionsList.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(getActivity(),InvoicesListActivity.class);
                startActivity(i);
            }
        });

        logout.setOnClickListener(new OnClickListener() {
            @Override
            public void onClick(View view) {

           //     ((ConTolk)getActivity().getApplication()).updateUserStatus("LoggedOut");
                ((ConTolk)getActivity().getApplication()).getFirebaseAuth().signOut();
                if (((ConTolk)getActivity().getApplication()).mAuthListener != null)
                    ((ConTolk)getActivity().getApplication()).getFirebaseAuth().removeAuthStateListener(((ConTolk)getActivity().getApplication()).mAuthListener);

                getActivity().finish();
                Intent Intent = new Intent(getActivity(), MainActivity.class);
            startActivity(Intent);
                Toast.makeText(getActivity(),"The user is logged out",Toast.LENGTH_SHORT).show();


            }
        });


                return view;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.customers_setting_menu, menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.menu_logout){
            ((ConTolk)getActivity().getApplication()).getFirebaseAuth().signOut();
            if (((ConTolk)getActivity().getApplication()).mAuthListener != null)
                ((ConTolk)getActivity().getApplication()).getFirebaseAuth().removeAuthStateListener(((ConTolk)getActivity().getApplication()).mAuthListener);

            Intent profileIntent = new Intent(getActivity(), MainActivity.class);
            startActivity(profileIntent);
            Toast.makeText(getActivity(),"The user is logged out",Toast.LENGTH_SHORT).show();
            getActivity().finish();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

}