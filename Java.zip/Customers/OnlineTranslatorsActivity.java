package tecno.khaledtar.com.contolk.Customers;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.TextView;
import android.widget.Toast;

import com.sinch.android.rtc.SinchError;

import tecno.khaledtar.com.contolk.Firebase.FirebaseDatabaseHelper;
import tecno.khaledtar.com.contolk.Helper.SimpleDividerItemDecoration;
import tecno.khaledtar.com.contolk.R;
import tecno.khaledtar.com.contolk.Snich.SinchService;
import tecno.khaledtar.com.contolk.Snich.BaseActivity;
import tecno.khaledtar.com.contolk.ConTolk;

public class OnlineTranslatorsActivity  extends AppCompatActivity {
   String languages;
   // private ProgressDialog mSpinner;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_online_translators);

        setTitle("Online Interpreters");
        languages=  getIntent().getExtras().getString("language_key");
      String userEmail=   ((ConTolk)this.getApplication()).getFirebaseAuth().getCurrentUser().getEmail();




        final RecyclerView recyclerView = (RecyclerView) findViewById(R.id.m_RecyclerView1);
        final TextView languageTexView = (TextView) findViewById(R.id.aviliableInterpreters_V2);
        languageTexView.setText(languages);


        LinearLayoutManager linerLayoutManager = new LinearLayoutManager(this, LinearLayoutManager.VERTICAL, false);
        recyclerView.setLayoutManager(linerLayoutManager);
        recyclerView.addItemDecoration(new SimpleDividerItemDecoration(this));
        recyclerView.setVerticalScrollBarEnabled(true);



        ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Searching for online interpreters,Please wait... ");
        progressDialog.setCanceledOnTouchOutside(false);

        FirebaseDatabaseHelper firebaseDatabaseHelper = new FirebaseDatabaseHelper();
        firebaseDatabaseHelper.availableTranslators(languages,userEmail, this, recyclerView, progressDialog);


    }


}
