package tecno.khaledtar.com.contolk.Customers;

import android.app.AlertDialog;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.content.DialogInterface;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.Toast;

import com.crashlytics.android.Crashlytics;
import com.sinch.android.rtc.SinchError;

import io.fabric.sdk.android.Fabric;
import tecno.khaledtar.com.contolk.ConTolk;
import tecno.khaledtar.com.contolk.Helper.Helper;
import tecno.khaledtar.com.contolk.R;
import tecno.khaledtar.com.contolk.Snich.BaseActivity;
import tecno.khaledtar.com.contolk.Snich.SinchService;

public class CustomerOperationsActivity extends BaseActivity implements SinchService.StartFailedListener {


public Fragment fragment;





    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            if(!Helper.checkInternetConnection(CustomerOperationsActivity.this)){
                 AlertDialog.Builder alert = new AlertDialog.Builder(CustomerOperationsActivity.this);
                alert.setTitle("No internet connection!, please check your internet setting")
                        .setIcon(R.drawable.ic_info_blue_a400_24dp)
                        .setNegativeButton("OK",new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                finish();
                            }
                        });
alert.show();

            }
            FragmentManager    fm =getSupportFragmentManager();
            FragmentTransaction  ft=fm.beginTransaction();
            switch (item.getItemId()) {


                case R.id.navigation_live_transnslation_customer:
                   setTitle("Select desired languages");

                    ft.replace(R.id.customerFragmentContainer,new LiveTranslationFragment());
                    ft.commit();
                   return true;

                case R.id.navigation_profile_customer:
                    setTitle("Profile");
                   ft.replace(R.id.customerFragmentContainer,new CustomerProfileFragment());
                    ft.commit();
                    return true;

                case R.id.navigation_settings_customer:
                    setTitle("Settings");
                   ft.replace(R.id.customerFragmentContainer,new Fragment_Customers_Settings());
                    ft.commit();
                    return true;
            }


          return false;

        }
    };





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Fabric.with(this, new Crashlytics());
        logUser();
        setContentView(R.layout.activity_customer_operations);

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation2);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        FragmentManager    fm =getSupportFragmentManager();
        FragmentTransaction  ft=fm.beginTransaction();
        ft.replace(R.id.customerFragmentContainer,new LiveTranslationFragment()).commit();
     //   setTitle("Select desired languages");



    }


    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();
        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }


    @Override
    protected void onServiceConnected() {
        getSinchServiceInterface().setStartListener(this);
        Toast.makeText(this, "Service is connected", Toast.LENGTH_SHORT).show();

    }



    @Override
    public void onStartFailed(SinchError error) {
        Toast.makeText(this, error.toString(), Toast.LENGTH_LONG).show();
    }

    @Override
    public void onStarted() {
        //openPlaceCallActivity();
    }

    @Override
    protected void onDestroy() {
 stopService(new Intent("tecno.khaledtar.com.contolk.Snich.SinchService").setPackage("tecno.khaledtar.com.contolk"));

        super.onDestroy();
    }

    private void logUser() {
        // TODO: Use the current user's information
        // You can call any combination of these three methods
        Crashlytics.setUserEmail(((ConTolk)this.getApplication()).getFirebaseAuth().getCurrentUser().getEmail());
        Crashlytics.setUserName("User is customer");
    }
}
