package tecno.khaledtar.com.contolk.Customers;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import tecno.khaledtar.com.contolk.Firebase.FirebaseDatabaseHelper;
import tecno.khaledtar.com.contolk.Helper.SimpleDividerItemDecoration;
import tecno.khaledtar.com.contolk.R;
import tecno.khaledtar.com.contolk.ConTolk;

//import com.delaroystudios.firebaselogin.Firebase.FirebaseDatabaseHelper;
//import com.delaroystudios.firebaselogin.Firebase.FirebaseStorageHelper;
//import com.delaroystudios.firebaselogin.Helper.Helper;
//import com.delaroystudios.firebaselogin.Helper.SimpleDividerItemDecoration;

public class CustomerProfileFragment extends Fragment {

    private static final String TAG = CustomerProfileFragment.class.getSimpleName();

    private ImageView profilePhoto;

    private TextView profileName;

   private TextView country;

    private TextView userStatus;

    private RecyclerView recyclerView;

    private LinearLayoutManager linearLayoutManager;

    private String id;

    public  String userType;

    FirebaseDatabaseHelper firebaseDatabaseHelper;

    private static final int REQUEST_READ_PERMISSION = 120;

    public CustomerProfileFragment() {

    }





    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_customer_profile, container, false);

        getActivity().setTitle("My Profile");

        profileName = (TextView)view.findViewById(R.id.profile_name);
        country = (TextView)view.findViewById(R.id.country);




        recyclerView = (RecyclerView)view.findViewById(R.id.profile_list);
       linearLayoutManager = new LinearLayoutManager(getActivity(), LinearLayoutManager.VERTICAL, false);

        recyclerView.setLayoutManager(linearLayoutManager);
       linearLayoutManager.setStackFromEnd(true);
        recyclerView.addItemDecoration(new SimpleDividerItemDecoration(getActivity()));
        recyclerView.setVerticalScrollBarEnabled(true);


   //  ((ConTolk)getActivity().getApplication()).getFirebaseAuth();
        id = ((ConTolk)getActivity().getApplication()).getFirebaseUserAuthenticateId();



       FirebaseDatabaseHelper firebaseDatabaseHelper = new FirebaseDatabaseHelper();

            firebaseDatabaseHelper.isUserKeyExist(id, getActivity(), recyclerView);


        return view;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.edit_profile, menu);
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if(id == R.id.action_edit_profile){
            Intent editUserProfileIntent = new Intent(getActivity(), EditCustomerProfileActivity.class);
               getActivity().startActivity(editUserProfileIntent);

            return true;
        }
        return super.onOptionsItemSelected(item);
    }







}
