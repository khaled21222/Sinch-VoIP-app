package tecno.khaledtar.com.contolk.Customers;

import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.IBinder;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.sinch.android.rtc.MissingPermissionException;
import com.sinch.android.rtc.SinchClient;
import com.sinch.android.rtc.SinchError;
import com.sinch.android.rtc.calling.Call;

import tecno.khaledtar.com.contolk.R;
import tecno.khaledtar.com.contolk.Snich.BaseActivity;
import tecno.khaledtar.com.contolk.Snich.CallScreenForUserActivity;
import tecno.khaledtar.com.contolk.Snich.SinchService;

public class SelectedTranslatorActivity extends AppCompatActivity {

    private Button mCallButton,stopButton;
    private RatingBar ratingBar;
    private EditText mCallName;
    private TextView descriptionTextview,languagesTextview,experianceTextview,genderTextview;
    private final int REQUEST_PERMISSION_CALL_PHONE=0,REQUEST_PERMISSION_READ_PHONE_STATE=1,REQUEST_PERMISSION_RECORD_AUDIO=2;
    String languages,profile,rating,translatorBalance,workinHours,tid,callerId,recipientId,experiance,gender,phoneNo;
    private SinchClient sinchClient;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_selected_translater);




        if ( ContextCompat.checkSelfPermission( this, android.Manifest.permission.RECORD_AUDIO ) != PackageManager.PERMISSION_GRANTED )
            ActivityCompat.requestPermissions(SelectedTranslatorActivity.this, new String[]{android.Manifest.permission.RECORD_AUDIO}, REQUEST_PERMISSION_RECORD_AUDIO);






        Intent intent = getIntent();
    callerId = intent.getStringExtra("callerId");
   recipientId = intent.getStringExtra("recipientId");



        languages=  getIntent().getExtras().getString("language_key");
        profile=  getIntent().getExtras().getString("profile_key");
        gender=  getIntent().getExtras().getString("gender_key");
        experiance=  getIntent().getExtras().getString("experiance_key");
        rating=  getIntent().getExtras().getString("rating_key");
        workinHours=  getIntent().getExtras().getString("totalHours_key");
        translatorBalance=  getIntent().getExtras().getString("balance_key");
        tid=  getIntent().getExtras().getString("tid_key");
        phoneNo=  getIntent().getExtras().getString("phoneNo_key");



        mCallButton = (Button) findViewById(R.id.callingButton);
        descriptionTextview = (TextView) findViewById(R.id.interpreterDescription_T1);
        genderTextview = (TextView) findViewById(R.id.genderView);
        experianceTextview = (TextView) findViewById(R.id.experianceYears);
        languagesTextview = (TextView) findViewById(R.id.languagesView);
        ratingBar=(RatingBar) findViewById(R.id.ratingBarView);


        ratingBar.setRating(Float.parseFloat(rating));
        descriptionTextview.setText("Profile:"+profile);
        languagesTextview.setText("Spoken languages:"+languages);
        genderTextview.setText("Gender:"+gender);
        experianceTextview.setText("Years of experience:"+experiance);

        setTitle(languages);


        mCallButton.setOnClickListener(buttonClickListener);


    }





    private void callButtonClicked() {

        String callReceiver = recipientId;
        if (callReceiver.isEmpty()) {
            Toast.makeText(this, "Please enter a user to call", Toast.LENGTH_LONG).show();
            return;
        }

        try {
            Call call = BaseActivity.getSinchServiceInterface().callUser(callReceiver);
            if (call == null) {
                // Service failed for some reason, show a Toast and abort
                Toast.makeText(this, "Service is not started. Try stopping the service and starting it again before "
                        + "placing a call.", Toast.LENGTH_LONG).show();
                return;
            }
            String callId = call.getCallId();
            Intent callScreen = new Intent(this, CallScreenForUserActivity.class);
            callScreen.putExtra(SinchService.CALL_ID, callId);
            callScreen.putExtra("tid_key",tid);
            callScreen.putExtra("rating_key", rating);
            callScreen.putExtra("totalHours_key", workinHours);
            callScreen.putExtra("balance_key", translatorBalance);
            callScreen.putExtra("language_key", languages);
            startActivity(callScreen);
        } catch (MissingPermissionException e) {
            ActivityCompat.requestPermissions(this, new String[]{e.getRequiredPermission()}, 0);
        }

    }



    private View.OnClickListener buttonClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            switch (v.getId()) {
                case R.id.callingButton:

                    showCallOptionDialog();

                    break;



            }
        }
    };


    private void showCallOptionDialog() {

       final AlertDialog.Builder builder = new AlertDialog.Builder(this,R.style.Dialog);

        builder.setView(R.layout.call_options_dialog);
        builder.setCancelable(true);
        builder.setTitle("What is the type of connection you want?");
        builder.create();


        final AlertDialog callOptionDialog = builder.create();
        callOptionDialog.show();


        Button regularCall = (Button) callOptionDialog.findViewById(R.id.regularCallButton);
        Button internetCall = (Button)callOptionDialog.findViewById(R.id.internetCallButton);
        regularCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent i=new Intent(SelectedTranslatorActivity.this,RegularCallActivity.class);
callOptionDialog.dismiss();
                i.putExtra("tid_key",tid);
                i.putExtra("rating_key", rating);
                i.putExtra("totalHours_key", workinHours);
                i.putExtra("balance_key", translatorBalance);
                i.putExtra("language_key", languages);
                i.putExtra("phoneNo_key", phoneNo);
                startActivity(i);
                finish();

            }
        });

        internetCall.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                callButtonClicked();
                callOptionDialog.dismiss();
               finish();
            }
        });



    }


    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        switch (requestCode) {
            case REQUEST_PERMISSION_RECORD_AUDIO: {

                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                    Toast.makeText(this, "You may now place a call", Toast.LENGTH_LONG).show();


                } else {
                    Toast.makeText(this, "This application needs permission to use your microphone to function properly.", Toast
                            .LENGTH_LONG).show();
                   finish();
                }
            }

/*

                case REQUEST_PERMISSION_CALL_PHONE: {

                    if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    } else {
                        Toast.makeText(this, "This application needs permission to access your call log.", Toast
                                .LENGTH_LONG).show();

                    }

                }

            case REQUEST_PERMISSION_READ_PHONE_STATE: {

                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                  //  Toast.makeText(this, "You may now place a call", Toast.LENGTH_LONG).show();
                } else {
                 //   Toast.makeText(this, "This application needs permission READ_PHONE_STATE", Toast
                        //    .LENGTH_LONG).show();
                    finish();
                }

            }
*/





        }


    }
}