package tecno.khaledtar.com.contolk.Customers;


import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

import tecno.khaledtar.com.contolk.ConTolk;
import tecno.khaledtar.com.contolk.R;

import static java.lang.Thread.sleep;


/**
 * A simple {@link Fragment} subclass.
 */
public class LiveTranslationFragment extends Fragment {

    public LiveTranslationFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view= inflater.inflate(R.layout.fragment_live_translation, container, false);


        //check if user alive
        ((ConTolk)getActivity().getApplication()).checkIfUserAlive(getActivity());

        final Button next=(Button) view.findViewById(R.id.goToList);
        final Spinner language=(Spinner) view.findViewById(R.id.languagesSpinner) ;

    //final Animation anim_rotate = AnimationUtils.loadAnimation(getActivity().getApplicationContext(), R.anim.rotate);
    // anim_rotate.setDuration(1500);

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                loginClicked();

                Intent i=new Intent(getActivity(),OnlineTranslatorsActivity.class);

                i.putExtra("language_key", language.getSelectedItem().toString());

             startActivity(i);



            }
        });

        return view;
    }



    private void loginClicked() {
        String userName =((ConTolk)getActivity().getApplication()).getFirebaseAuth().getCurrentUser().getEmail();

        if (userName.isEmpty()) {
            Toast.makeText(getActivity(), "Please enter a name", Toast.LENGTH_LONG).show();
            return;
        }

        if (!userName.equals(((CustomerOperationsActivity)getActivity()).getSinchServiceInterface().getUserName())) {
            ((CustomerOperationsActivity)getActivity()).getSinchServiceInterface().stopClient();
        }

        if (!((CustomerOperationsActivity)getActivity()).getSinchServiceInterface().isStarted()) {
            ((CustomerOperationsActivity)getActivity()).getSinchServiceInterface().startClient(userName);

        } else {
            // openPlaceCallActivity();
        }
    }


}
