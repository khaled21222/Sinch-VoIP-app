package tecno.khaledtar.com.contolk.Customers;

import android.Manifest;
import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.AudioManager;
import android.net.Uri;
import android.provider.CallLog;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.TelephonyManager;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.EditText;
import android.telephony.PhoneStateListener;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;


import tecno.khaledtar.com.contolk.Firebase.FirebaseDatabaseHelper;
import tecno.khaledtar.com.contolk.Firebase.FirebaseTransactionEntity;
import tecno.khaledtar.com.contolk.Helper.Helper;
import tecno.khaledtar.com.contolk.InvoicesListActivity;
import tecno.khaledtar.com.contolk.R;
import tecno.khaledtar.com.contolk.ConTolk;
import tecno.khaledtar.com.contolk.Snich.CallScreenForUserActivity;

import static java.lang.Thread.sleep;

public class RegularCallActivity extends AppCompatActivity {
    Button endButton;
    Button callButton;
    TextView callDetails;
    FirebaseUser user;

    // private String callDuration;
    //  private int duration;
    private TelephonyManager telephonyManager;
    FirebaseAuth mAuth;
    private StateListener phoneStateListener;
    private final int REQUEST_PERMISSION_CALL_PHONE = 1;
    protected String tId, rating, currentDate,translatorWorkingHours,translatorbalance;
    protected FirebaseDatabaseHelper firebaseDatabaseHelper;
    private String phoneNo,language;
    // private String langauge;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calling);


        int PERMISSION_ALL = 1;
        String[] PERMISSIONS = {Manifest.permission.CALL_PHONE, Manifest.permission.READ_PHONE_STATE, Manifest.permission.READ_CALL_LOG};

        if(!hasPermissions(this, PERMISSIONS)){
            ActivityCompat.requestPermissions(this, PERMISSIONS, PERMISSION_ALL);

        }

        callButton = (Button) findViewById(R.id.callButton);
        endButton = (Button) findViewById(R.id.endCallButton);
        callDetails = (TextView) findViewById(R.id.callDetails_T);
        firebaseDatabaseHelper = new FirebaseDatabaseHelper();

     //start animi
        Animation animation = new AlphaAnimation(1, 0);
        animation.setDuration(1000);
        animation.setInterpolator(new LinearInterpolator());
        animation.setRepeatCount(Animation.INFINITE);
        animation.setRepeatMode(Animation.REVERSE);
        callDetails.startAnimation(animation);




        currentDate = Helper.getCurrentDateTime();
        user = FirebaseAuth.getInstance().getCurrentUser();
        // prepare customer info
        firebaseDatabaseHelper.getCustomerInfoById(user.getUid().toString());

        tId = getIntent().getStringExtra("tid_key");
        rating = getIntent().getStringExtra("rating_key");
        phoneNo = getIntent().getStringExtra("phoneNo_key");
        translatorWorkingHours =getIntent().getExtras().getString("totalHours_key");
        translatorbalance =getIntent().getExtras().getString("balance_key");
        language =getIntent().getExtras().getString("language_key");


        phoneStateListener = new StateListener();
        telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
        telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_CALL_STATE);





        callButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Runnable runnable=new Runnable(){

                    @Override
                    public void run() {
                        tId = getIntent().getStringExtra("tid_key");
                        phoneNo = getIntent().getStringExtra("phoneNo_key");
                        Intent callIntent = new Intent(Intent.ACTION_CALL);
                        callIntent.setData(Uri.parse("tel: " +  phoneNo));  // change the no

                        Toast.makeText(getApplication(), "Just a few secounds and you'll get connected...", Toast.LENGTH_LONG).show();
                        // get permission
                        if (ActivityCompat.checkSelfPermission(RegularCallActivity.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                            ActivityCompat.requestPermissions(RegularCallActivity.this, new String[]{android.Manifest.permission.CALL_PHONE}, REQUEST_PERMISSION_CALL_PHONE);
                            return;
                        }

                        startActivity(callIntent);

                        //recall Activity

                             try {
                          sleep(1700);
                        Intent i = new Intent(RegularCallActivity.this,RegularCallActivity.class);

                        i.putExtra("tid_key",tId);
                        i.putExtra("rating_key",rating);
                        i.putExtra("phoneNo_key",phoneNo);
                        i.putExtra("totalHours_key",translatorWorkingHours);
                        i.putExtra("balance_key",translatorbalance);
                        i.putExtra("language_key",language);

                        finish();
                        startActivity(i);

                               } catch (InterruptedException e) {
                             }

                    }
                };

               Thread callThread=new Thread(runnable);
               callThread.run();





             }
        });


        endButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {
                    Class c = Class.forName(telephonyManager.getClass().getName());
                    Method m = c.getDeclaredMethod("getITelephony");
                    m.setAccessible(true);
                    Object telephonyService = m.invoke(telephonyManager);

                    c = Class.forName(telephonyService.getClass().getName());
                    m = c.getDeclaredMethod("endCall");
                    m.setAccessible(true);
                    m.invoke(telephonyService);

                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });


    }

    private boolean hasPermissions(RegularCallActivity regularCallActivity, String[] permissions) {

        if (regularCallActivity != null && permissions != null) {
            for (String permission : permissions) {
                if (ActivityCompat.checkSelfPermission(regularCallActivity, permission) != PackageManager.PERMISSION_GRANTED) {
                    return false;
                }
            }
        }
        return true;
    }

    private void addTransaction(String formattedDate,Double amount,Double callDuration) {

         //add new transaction
        FirebaseTransactionEntity trans = new FirebaseTransactionEntity();
        trans.setC_Id_Id(user.getUid().toString());
        trans.setT_Id(getIntent().getStringExtra("tid_key")  );
        trans.setdateandTime(formattedDate );
        trans.setcallDuration(String.valueOf(callDuration));
        trans.setpricePerMinute("10 DDK");
        trans.setDeservedAmount(String.valueOf(amount));
        firebaseDatabaseHelper.addTransaction(trans,user.getUid().toString());

         //update translator record
         Double translatorWorkingTime=Double.parseDouble(getIntent().getExtras().getString("totalHours_key"));
         Double updatedTranslatorWorkingTime=translatorWorkingTime+callDuration;

         Double translatorBalance=Double.parseDouble(getIntent().getExtras().getString("balance_key"));
         Double updatedTranslatorBalance=translatorBalance+(amount*30/100);
         Map<String, Object> translatorProfile = new HashMap<String, Object>();
         translatorProfile.put("totalWorkingTime",String.valueOf(updatedTranslatorWorkingTime));
         translatorProfile.put("Balance",String.valueOf(updatedTranslatorBalance));
         firebaseDatabaseHelper.createTranslatorInFirebaseDatabase(tId,translatorProfile);

//update customer record

        Double customerTotalTime=Double.parseDouble(firebaseDatabaseHelper.customerInfo.getTotalTime());
        Double updatedCustomerToltalTime=customerTotalTime+callDuration;

         Double userBalance=Double.parseDouble(firebaseDatabaseHelper.customerInfo.getBalance());
         Double updatedUserBalance=userBalance+amount;

         Map<String, Object> customerProfile = new HashMap<String, Object>();
         customerProfile.put("Balance",String.valueOf(updatedUserBalance));
        customerProfile.put("TotalTime",String.valueOf(updatedCustomerToltalTime));
         firebaseDatabaseHelper.createUserInFirebaseDatabase(user.getUid().toString(),customerProfile);



    }

    public  class StateListener extends PhoneStateListener {

        Double callDuration;
        Double amount ;
        private Boolean iscalling = false;

        @Override
        public void onCallStateChanged(int state, String incomingNumber) {
            super.onCallStateChanged(state, incomingNumber);

            AudioManager audioManager = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
            audioManager.setMode(AudioManager.MODE_IN_CALL);




            switch (state) {
                case TelephonyManager.CALL_STATE_RINGING:

                    break;
                case TelephonyManager.CALL_STATE_OFFHOOK:
                    iscalling = true;
                    audioManager.setSpeakerphoneOn(true);
                    callDetails.setText("Call in progress....");
                  firebaseDatabaseHelper.updateTranslatorStatus(tId,language,"Reserved");
                    break;

                case TelephonyManager.CALL_STATE_IDLE:
                    telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE);
                    if(iscalling){

                        audioManager.setSpeakerphoneOn(false);
                        firebaseDatabaseHelper.updateTranslatorStatus(tId,language,"Available");
                        Runnable runnable=new Runnable() {
                            @Override
                            public void run() {

                                try {
                                    sleep(1500);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }

                                try {

                                    Cursor managedCursor = null;
                                    managedCursor = getContentResolver().query(CallLog.Calls.CONTENT_URI, null, null, null, CallLog.Calls.DATE + " DESC limit 1;");
                                    managedCursor.moveToFirst();

                                    String number = CallLog.Calls.getLastOutgoingCall(RegularCallActivity.this);
                                    int type = managedCursor.getColumnIndex(CallLog.Calls.TYPE);
                                    int date = managedCursor.getColumnIndex(CallLog.Calls.DATE);
                                    int duration = managedCursor.getColumnIndex(CallLog.Calls.DURATION);
                                    String callType = managedCursor.getString(type);



                                    int callDurationInSecounds = managedCursor.getInt(duration);

                                    int hours = callDurationInSecounds / 3600;
                                    int minutes = (callDurationInSecounds%3600)/60;
                                    int seconds_output = (callDurationInSecounds% 3600)%60;


                                    amount=hours*600+minutes*10+seconds_output*0.1666;
                                    callDuration=hours*60+minutes+seconds_output/60.0;

                                    int dircode = Integer.parseInt(callType);

                                    // get current date and time for transaction
                                    Calendar c = Calendar.getInstance();
                                    SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                                    String formattedDate = df.format(c.getTime());

                                    //     ((ConTolk)this.getApplication()).getFirebaseAuth();
                                    managedCursor.close();




                                    if  ((dircode == CallLog.Calls.OUTGOING_TYPE) && (callDuration>1.0)) {

                                        addTransaction(formattedDate,amount,callDuration);
                                        showEndServiceDialog();

                                    } else

                                        finish();


                                    iscalling = false;
                                    callDetails.setText("call is ended");
                                    callDetails.clearAnimation();

                                } catch (SecurityException e) {
                                    System.out.println();
                                    // lets the user know there is a problem with the code
                                }
                            }
                        } ;

                        Thread transactionThread=new Thread(runnable);
                        transactionThread.run();

                    }
                    break;

                default:
                    break;


            }


        }



        private void showEndServiceDialog(){

            final AlertDialog.Builder alert = new AlertDialog.Builder(RegularCallActivity.this);
            alert.setTitle("What do you want to do?")
                    .setCancelable(false)

                    .setNegativeButton("CANCEL",new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {

                     finish();
                        }
                    })
                 /*   .setPositiveButton("INVOICE",
                    new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog,int whichButton) {


Intent i=new Intent(RegularCallActivity.this,InvoicesListActivity.class);
finish();
startActivity(i);

                        }
                    })  */

                    .setNeutralButton("RATE THE SERVICE",
                            new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog,int whichButton){


                                final Dialog rankDialog = new Dialog(RegularCallActivity.this);

                                        rankDialog.setContentView(R.layout.rating);
                                        rankDialog.setCancelable(true);
                                       final RatingBar ratingBar = (RatingBar)rankDialog.findViewById(R.id.ratingBar2);
                                    final EditText feedback = (EditText)rankDialog.findViewById(R.id.userfeedback);
                                        //ratingBar.setRating(6);
                                        Button updateButton = (Button) rankDialog.findViewById(R.id.rateButton);
                                        updateButton.setOnClickListener(new View.OnClickListener() {
                                            @Override
                                            public void onClick(View v) {

                                                // update translator rating

                                                float updatedRating,currentRateing;


                                                currentRateing= Float.parseFloat(getIntent().getStringExtra("rating_key"));
                                                if(currentRateing==0)
                                                    updatedRating=ratingBar.getRating();
                                                else
                                                    updatedRating=(currentRateing+ratingBar.getRating())/2;

                                                rankDialog.dismiss();
                                                Toast.makeText(RegularCallActivity.this,"Thank you,your feedback will be considered.",Toast.LENGTH_LONG).show();


                                                Map<String, Object> userProfile = new HashMap<String, Object>();
                                                userProfile.put("Rating",String.valueOf(updatedRating));
                                                FirebaseDatabaseHelper firebaseDatabaseHelper = new FirebaseDatabaseHelper();
                                             firebaseDatabaseHelper.createTranslatorInFirebaseDatabase(tId,userProfile);

                                                if (!feedback.getText().toString().equals(""))
                                                firebaseDatabaseHelper.addFeedBack(user.getUid().toString(),tId,feedback.getText().toString(),currentDate);
                                                finish();
                                            }
                                        });
                                        //now that the dialog is set up, it's time to show it
                                        rankDialog.show();

                                }
                            });
            alert.show();

        }


    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch(requestCode){
            case REQUEST_PERMISSION_CALL_PHONE:
                if (grantResults[0]==PackageManager.PERMISSION_GRANTED) {


                }
                else
                {
                    // Permission Denied
                    Toast.makeText(this, "REQUEST_PERMISSION_CALL_PHONE", Toast.LENGTH_SHORT).show();

                }



        }

    }
}