package tecno.khaledtar.com.contolk;


import android.support.annotation.Nullable;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.Fragment;

import android.os.Bundle;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;


import tecno.khaledtar.com.contolk.Helper.Helper;


/**
 * A simple {@link Fragment} subclass.
 */
public class Fragment_login extends Fragment {
    private ProgressBar progressBar;

     EditText emailInput;

     EditText passwordInput;

    Spinner userType;
    TextView signUpText;

    FirebaseAuth mAuth;
    final String who=null;

    public Fragment_login() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {




         final TextView loginError;
        // Inflate the layout for this fragment
        View view=inflater.inflate(R.layout.fragment_fragment_login, container, false);
         emailInput =(EditText) view.findViewById(R.id.email);
        passwordInput = (EditText)view.findViewById(R.id.password);
        loginError = (TextView)view.findViewById(R.id.login_error);
        progressBar= (ProgressBar) view.findViewById(R.id.progressBar);




        signUpText = (TextView)view.findViewById(R.id.register);
        signUpText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Fragment_signUp fragment = new  Fragment_signUp();
                FragmentManager fm =getFragmentManager();
                FragmentTransaction ft=fm.beginTransaction();
                ft.replace(R.id.fragmentMain,fragment);
                ft.commit();
            }
        });

        final Button loginButton = (Button)view.findViewById(R.id.login_button);
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                progressBar.setVisibility(View.VISIBLE);

                String enteredEmail = emailInput.getText().toString();
                String enteredPassword = passwordInput.getText().toString();

                if(TextUtils.isEmpty(enteredEmail) || TextUtils.isEmpty(enteredPassword)){
                    Helper.displayMessageToast(getActivity(), "Login fields must be filled");
                    return;
                }
                if(!Helper.isValidEmail(enteredEmail)){
                    Helper.displayMessageToast(getActivity(), "Invalidate email entered");
                    return;
                }

                //cheacking internet
                //((ConTolk)getActivity().getApplication()).checkInternetConnection(getActivity());

                ((ConTolk)getActivity().getApplication()).loginAUser(getActivity(),progressBar, enteredEmail, enteredPassword, loginError);

            }
        });


        return view;
    }

    @Override
    public void onViewCreated(View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);


    }









}
