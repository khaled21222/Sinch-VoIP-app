package tecno.khaledtar.com.contolk.Adapters;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import tecno.khaledtar.com.contolk.Customers.OnlineTranslatorsActivity;
import tecno.khaledtar.com.contolk.Customers.SelectedTranslatorActivity;
import tecno.khaledtar.com.contolk.Firebase.FirebaseTranslatorEntity;
import tecno.khaledtar.com.contolk.R;

/**
 * Created by Khaled on 08-Jan-18.
 */

public class FirebaseViewHolder extends RecyclerView.ViewHolder {
    View mView;
    Context mContext;
    private CardView cardView;
    private ImageView imageView;
    private TextView TextName;
    private Button callButton;


    private android.support.v4.app.FragmentManager fm;
    FragmentTransaction ft ;

    public FirebaseViewHolder(View itemView) {
        super(itemView);
         mView = itemView;
        mContext = itemView.getContext();

    }

    public void bindview(final String userName, final FirebaseTranslatorEntity Translator_AD, ProgressDialog mProgressDialog) {
        cardView = (CardView) mView.findViewById(R.id.cardView);
        imageView = (ImageView) mView.findViewById(R.id.profile_image);
        TextName = (TextView) mView.findViewById(R.id.TextName);
        callButton = (Button) mView.findViewById(R.id.callButton);


        if (mProgressDialog.isShowing())
            mProgressDialog.dismiss();



        TextName.setText(Translator_AD.getName());
    //    imageView.setImageResource(List_Item_of_aviliable_translators.get(position).getImg());

    callButton.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {

            Intent i=new Intent(mContext,SelectedTranslatorActivity.class);

            i.putExtra("phoneNo_key", Translator_AD.getPhone());
            i.putExtra("tid_key", Translator_AD.getuId());
            i.putExtra("rating_key", Translator_AD.getRatings());
            i.putExtra("totalHours_key", Translator_AD.getTotalWorkingTime());
            i.putExtra("balance_key", Translator_AD.getBalance());

            i.putExtra("language_key", Translator_AD.getLanguage());
            i.putExtra("name_key", Translator_AD.getName());
            i.putExtra("email_key", Translator_AD.getEmail());
            i.putExtra("profile_key", Translator_AD.getProfile());
            i.putExtra("gender_key", Translator_AD.getGender());
            i.putExtra("experiance_key", Translator_AD.getYearsExperiance());

            i.putExtra("callerId", userName);
            i.putExtra("recipientId",Translator_AD.getEmail());



            mContext.startActivity(i);
            ((OnlineTranslatorsActivity) mContext).finish();




        }
    });


    }


}

