package tecno.khaledtar.com.contolk.Adapters;

import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import tecno.khaledtar.com.contolk.Customers.OnlineTranslatorsActivity;
import tecno.khaledtar.com.contolk.Customers.SelectedTranslatorActivity;
import tecno.khaledtar.com.contolk.List_Item;
import tecno.khaledtar.com.contolk.R;

import java.util.List;


public class RecyclerView_dAdapter extends RecyclerView.Adapter<RecyclerView_dAdapter.ViewHolder>{

    private List<List_Item> List_Item;
    private Context context;
    private FragmentManager fm;
   String userEmail;
   ProgressDialog mProgressDialog;

    public RecyclerView_dAdapter(List<List_Item> list_Item, Context context, String userEmail, ProgressDialog progressDialog) {
        List_Item = list_Item;
        this.context = context;
        this.userEmail=userEmail;
        this.mProgressDialog=progressDialog;

    }

    @Override
    public RecyclerView_dAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.row_item, parent, false);
        ViewHolder viewHolder = new ViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView_dAdapter.ViewHolder holder, final int position) {
       if (mProgressDialog.isShowing())
               mProgressDialog.dismiss();

        holder.TextName.setText(List_Item.get(position).getTranslator().getName());
      //  holder.imageView.setImageResource(List_Item.get(position).getImg());
        //Picasso.with(context).load(List_Item.get(position).img).into(holder.imageView);


        holder.callButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i=new Intent(context, SelectedTranslatorActivity.class);

                i.putExtra("phoneNo_key", List_Item.get(position).getTranslator().getPhone());
                i.putExtra("tid_key", List_Item.get(position).getTranslator().getuId());
                i.putExtra("rating_key", List_Item.get(position).getTranslator().getRatings());
                i.putExtra("totalHours_key", List_Item.get(position).getTranslator().getTotalWorkingTime());
                i.putExtra("balance_key", List_Item.get(position).getTranslator().getBalance());
                i.putExtra("profile_key", List_Item.get(position).getTranslator().getProfile());
                i.putExtra("language_key", List_Item.get(position).getTranslator().getLanguage());
                i.putExtra("name_key", List_Item.get(position).getTranslator().getName());
                i.putExtra("email_key", List_Item.get(position).getTranslator().getEmail());


                //loginClicked();
                context.startActivity(i);
                ((OnlineTranslatorsActivity) context).finish();




            }
        });
    }



    @Override
    public int getItemCount() {
        return (null != List_Item ? List_Item.size() : 0);
    }

    protected class ViewHolder extends RecyclerView.ViewHolder{
        private CardView cardView;
        private ImageView imageView;
        private TextView TextName;
        Button callButton;
        Fragment fragment1;

        public ViewHolder(View view) {
            super(view);

            cardView = (CardView) view.findViewById(R.id.cardView);
            imageView = (ImageView) view.findViewById(R.id.profile_image);
            TextName = (TextView) view.findViewById(R.id.TextName);
            callButton = (Button) view.findViewById(R.id.callButton);



        }
    }

 /*   private  void loginClicked() {
        String userName = userEmail;

        if (userName.isEmpty()) {
            Toast.makeText(context, "There is No username for Snich service", Toast.LENGTH_LONG).show();
            return;
        }

        if (!userName.equals(((OnlineTranslatorsActivity)context).getSinchServiceInterface().getUserName())) {
            ((OnlineTranslatorsActivity)context).getSinchServiceInterface().stopClient();
        }

        if (!((OnlineTranslatorsActivity)context).getSinchServiceInterface().isStarted()) {
            ((OnlineTranslatorsActivity)context).getSinchServiceInterface().startClient(userName);
            ((OnlineTranslatorsActivity)context).showSpinner();
        } else {
           // ((OnlineTranslatorsActivity)context).openPlaceCallActivity();
        }

    }  */
}