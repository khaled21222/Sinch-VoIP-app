package tecno.khaledtar.com.contolk.Adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.List;

import tecno.khaledtar.com.contolk.R;
import tecno.khaledtar.com.contolk.Translators.TranslatorProfile;

//import com.delaroystudios.firebaselogin.R;
//import com.delaroystudios.firebaselogin.CustomerProfile;

public class RecyclerViewAdapterTranslator extends RecyclerView.Adapter<RecyclerViewHolders> {

    private List<TranslatorProfile> translator;


    protected Context context;

    public RecyclerViewAdapterTranslator(Context context, List<TranslatorProfile> translator) {
        this.translator = translator;
        this.context = context;
    }



    @Override
    public RecyclerViewHolders onCreateViewHolder(ViewGroup parent, int viewType) {
        RecyclerViewHolders viewHolder = null;
        View layoutView = LayoutInflater.from(parent.getContext()).inflate(R.layout.profile_data_list, parent, false);
        viewHolder = new RecyclerViewHolders(layoutView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolders holder, int position) {
        holder.profileHeader.setText(translator.get(position).getHeader());
        holder.profileContent.setText(translator.get(position).getProfileContent());
    }

    @Override
    public int getItemCount() {
        return this.translator.size();
    }

}
