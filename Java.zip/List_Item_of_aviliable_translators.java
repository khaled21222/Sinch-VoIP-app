package tecno.khaledtar.com.contolk;

/**
 * Created by Khaled on 26-Dec-17.
 */

public class List_Item_of_aviliable_translators {

    public String name,translatorPhoneNo,tid;
    public int img;

    public List_Item_of_aviliable_translators(String name,String id,String phone){
        this.name = name;
        this.img = img;
        this.translatorPhoneNo=phone;
        this.tid=id;
    }

    public String getName() {
        return name;
    }
    public String getTid() {
        return tid;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getImg() {
        return img;
    }
    public String getTranslatorPhoneNo() {
        return translatorPhoneNo;
    }

    public void setImg(int img) {
        this.img = img;
    }

    public void setTranslatorPhoneNo(String translatorPhoneNo) {
        this.translatorPhoneNo = translatorPhoneNo;
    }
}