package tecno.khaledtar.com.contolk;

import android.app.ProgressDialog;
import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.widget.TextView;
import android.widget.Toast;

import com.crashlytics.android.Crashlytics;
import com.google.firebase.crash.FirebaseCrash;

import io.fabric.sdk.android.Fabric;
import tecno.khaledtar.com.contolk.Snich.SinchService;
import tecno.khaledtar.com.contolk.Translators.Fragment_TranslatorsStatusUpdate;

import static tecno.khaledtar.com.contolk.Snich.BaseActivity.getSinchServiceInterface;


public class MainActivity extends AppCompatActivity{
    private ProgressDialog mSpinner;
    private TextView mTextMessage;
    Fragment fragment;
  FragmentManager fm;
  FragmentTransaction ft;
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            fm =getSupportFragmentManager();
            ft=fm.beginTransaction();

            switch (item.getItemId()) {
                case R.id.navigation_home:
                      fragment = new Fragment_login();

                    ft.replace(R.id.fragmentMain,fragment);
                    ft.commit();
                    return true;
                case R.id.navigation_dashboard:

                      fragment = new Fragment_about();

                ft.replace(R.id.fragmentMain,fragment);
                ft.commit();
                return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
       super.onCreate(savedInstanceState);
        setContentView (R.layout.activity_main);

        FragmentManager fm =getSupportFragmentManager();
        FragmentTransaction ft=fm.beginTransaction();
        ft.replace(R.id.fragmentMain,new Fragment_login()).commit();




        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);


    }



    boolean doubleBackToExitPressedOnce = false;

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Please click BACK again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }





    @Override
    protected void onStop() {
        super.onStop();

}








}