package tecno.khaledtar.com.contolk;

import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Environment;
import android.support.v4.content.FileProvider;
import android.widget.Toast;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import java.io.File;
import java.io.FileOutputStream;
import java.text.DecimalFormat;

import tecno.khaledtar.com.contolk.Firebase.FirebaseTransactionEntity;



/**
 * Created by Khaled on 03-Feb-18.
 */
public class PrintReport {
    private static final String AUTHORITY="tecno.khaledtar.com.contolk";

    public static void main(String args,FirebaseTransactionEntity transaction,String customerInfo,Context context) {

        String pdfFilename = "";
        PrintReport printReport = new PrintReport();


        pdfFilename = args.trim();
        printReport.createPDF(pdfFilename,transaction,customerInfo,context);

    }

    private void createPDF (String pdfFilename, FirebaseTransactionEntity transaction,String customerInfo,Context context){

        Document doc = new Document();
        PdfWriter docWriter = null;

        DecimalFormat df = new DecimalFormat("0.00");

        try {

            //special font sizes
            Font bfBold12 = new Font(Font.FontFamily.TIMES_ROMAN, 12, Font.BOLD, new BaseColor(0, 0, 0));
            Font bf12 = new Font(Font.FontFamily.TIMES_ROMAN, 12);

            //file path
             String dirpath = Environment.getExternalStorageDirectory().getAbsolutePath() + "/";
            PdfWriter.getInstance(doc, new FileOutputStream(dirpath + "Invoice.pdf"));

          //  String path = "docs/" + pdfFilename;
            //docWriter = PdfWriter.getInstance(doc ,  Environment.getExternalStorageDirectory() + "/" + path + "/" + file);

            //document header attributes
            doc.addAuthor("T-Mediator");
            doc.addCreationDate();
            doc.addProducer();
            doc.addCreator("T-Mediator");
            doc.addTitle("Translation service invoice");
            doc.setPageSize(PageSize.A4);
            doc.addSubject("Invoice");

            //open document
            doc.open();

            //header
            Font f=new Font(Font.FontFamily.TIMES_ROMAN,20.0f,Font.UNDERLINE,BaseColor.GRAY);
            Paragraph paragraphTitle = new Paragraph("INVOICE",f);
            paragraphTitle.setSpacingAfter(20);
            paragraphTitle.setAlignment(Element.ALIGN_CENTER);


            Font f2=new Font(Font.FontFamily.TIMES_ROMAN,15.0f,Font.BOLD,BaseColor.GRAY);
            Paragraph paragraphReciver  = new Paragraph("Fakturamodtager".toUpperCase()+"\n"+"____________________________________________________________________".toUpperCase());
            Paragraph paragraphSender  = new Paragraph("Fakturaafsender".toUpperCase());


            Paragraph SenderInfo  = new Paragraph();
            SenderInfo.add("_________________________________________________________________________");
            SenderInfo.add("\n"+"T-Mediator co.".toUpperCase());
            SenderInfo.add("\n"+"Aalborg 9210".toUpperCase());
            SenderInfo.setSpacingAfter(20);



            //body
            Paragraph paragraph = new Paragraph(customerInfo.toUpperCase());


            //specify column widths
            float[] columnWidths = {8f, 4f, 4f, 4f,4f};
            //create PDF table with the given widths
            PdfPTable table = new PdfPTable(columnWidths);
            // set table width a percentage of the page width
            table.setWidthPercentage(100f);

            //insert column headings
            insertCell(table, "Description", Element.ALIGN_LEFT, 1, bfBold12);
            insertCell(table, "Duration", Element.ALIGN_LEFT, 1, bfBold12);
            insertCell(table, "UnitPrice", Element.ALIGN_LEFT, 1, bfBold12);
            insertCell(table, "Amount", Element.ALIGN_LEFT, 1, bfBold12);
            insertCell(table, "Date", Element.ALIGN_LEFT, 1, bfBold12);
            table.setHeaderRows(1);
            table.setSpacingAfter(20);

            //insert an empty row
           // insertCell(table, "", Element.ALIGN_LEFT, 4, bfBold12);
            //create section heading by cell merging
           // insertCell(table, "New York Orders ...", Element.ALIGN_LEFT, 4, bfBold12);
         //   double orderTotal, total = 0;

            //just some random data to fill

          Paragraph paragraph3 = new Paragraph("Subtotal without VAT     "

           +String.format( " %.2f", Double.parseDouble(transaction.getDeservedAmount()))
                  +"\n"+ "VAT 25% of 0,00     "+String.format( " %.2f", Double.parseDouble(transaction.getDeservedAmount())*25/100)+"\n"+
                "Total (DDK)     "+String.format( " %.2f", Double.parseDouble(transaction.getDeservedAmount())*25/100 +Double.parseDouble(transaction.getDeservedAmount())) );


            paragraph3.setSpacingAfter(20);
           paragraph3.setAlignment(Element.ALIGN_RIGHT);


         Font f3=new Font(Font.FontFamily.TIMES_ROMAN,15.0f,Font.NORMAL,BaseColor.BLACK);
            Paragraph  paragraph4= new Paragraph("____________________________________________________________________"+"\n"+"Sidste betalingsdato: 20xx-x1-x0"+"\n"+
                    " Indenlandsk kontooverførsel: (DK:BANK)"+"\n"+
                    "Reg.nr: xx40 Kontonr: xxxxxxx381",f3 );
            paragraph4.setAlignment(Element.ALIGN_LEFT);



            insertCell(table,  "Interpretation via phone call for "+String.format( " %.2f", Double.parseDouble(transaction.getCallDuration()) )+"minutes"+"\n"+"Translator Ref: "+ transaction.getT_Id(),Element.ALIGN_LEFT, 1, bf12);
            insertCell(table,String.format( " %.2f", Double.parseDouble(transaction.getCallDuration())) +" Minutes" , Element.ALIGN_LEFT, 1, bf12);
             insertCell(table,transaction.getPricePerMinute()+" per minute", Element.ALIGN_LEFT, 1, bf12);
          insertCell(table,String.format( " %.2f", Double.parseDouble(transaction.getDeservedAmount()))+" DDK", Element.ALIGN_LEFT, 1, bf12);
             insertCell(table,transaction.getDateandTime(), Element.ALIGN_LEFT, 1, bf12);


            //merge the cells to create a footer for that section
     //    insertCell(table, "............................", Element.ALIGN_RIGHT, 3, bfBold12);
           // insertCell(table, df.format(total), Element.ALIGN_RIGHT, 1, bfBold12);





            //add the PDF table to the paragraph
          //  paragraph.add(table);


            // add the paragraph to the document
            doc.add(paragraphTitle);
            doc.add(paragraphReciver);
            doc.add(paragraph);
            doc.add(paragraphSender);
            doc.add(SenderInfo);
            doc.add(table);

            doc.add(paragraph3);
            doc.add(paragraph4);







            viewPdf("Invoice.pdf", "PDF",  context);

        }
        catch (DocumentException dex)
        {
            dex.printStackTrace();
        }
        catch (Exception ex)
        {
            ex.printStackTrace();
        }
        finally
        {
            if (doc != null){
                //close the document
                doc.close();
            }
            if (docWriter != null){
                //close the writer
                docWriter.close();
            }
        }

    }

    private void insertCell(PdfPTable table, String text, int align, int colspan, Font font){

        //create a new cell with the specified Text and Font
        PdfPCell cell = new PdfPCell(new Phrase(text.trim(), font));
        //set the cell alignment
        cell.setHorizontalAlignment(align);
        //set the cell column span in case you want to merge two or more cells
        cell.setColspan(colspan);
        //in case there is no text and you wan to create an empty row
        if(text.trim().equalsIgnoreCase("")){
            cell.setMinimumHeight(10f);
        }
        //add the call to the table
        table.addCell(cell);

    }

    // Method for opening a pdf file
    private void viewPdf(String file, String directory, Context context) {

        File pdfFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath()  + "/" + file);
      //  Uri path = Uri.fromFile(pdfFile);
        Uri path = FileProvider.getUriForFile(context, context.getApplicationContext().getPackageName(), pdfFile);

        // Setting the intent for pdf reader
        Intent i=new Intent(Intent.ACTION_VIEW, FileProvider.getUriForFile(context, AUTHORITY, pdfFile));
        i.setDataAndType(path, "application/pdf");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        try {
            context.startActivity(i);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(context, "Can't read pdf file", Toast.LENGTH_SHORT).show();
        }
    }


}