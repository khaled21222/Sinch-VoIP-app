package tecno.khaledtar.com.contolk;

import android.app.ProgressDialog;
import android.content.pm.PackageManager;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;
import android.Manifest;


import tecno.khaledtar.com.contolk.Customers.RegularCallActivity;
import tecno.khaledtar.com.contolk.Firebase.FirebaseDatabaseHelper;

public class InvoicesListActivity extends AppCompatActivity {
ListView lv;
    String  uid , invoiceRef;
     FirebaseDatabaseHelper databaseHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_invoices_list);

         setTitle("Invoices List");
         ProgressDialog progressDialog=new ProgressDialog(this);
        progressDialog.setMessage("Preparing the invoices list... ");
        progressDialog.setCanceledOnTouchOutside(false);
        progressDialog.show();


        lv=(ListView) findViewById(R.id.invoicesListView);
        databaseHelper=new FirebaseDatabaseHelper();
        uid = ((ConTolk)getApplication()).getFirebaseUserAuthenticateId();
        String userType=((ConTolk)getApplication()).userType;
        databaseHelper.getTransactionsListOfCurrentUser(uid,userType,this,lv,progressDialog);






        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {

                // get permition
                if (ActivityCompat.checkSelfPermission(InvoicesListActivity.this, android.Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(InvoicesListActivity.this, new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);


                }


             int startIndex = lv.getItemAtPosition(i).toString().indexOf("(");
              int endIndex = lv.getItemAtPosition(i).toString().indexOf(")");
                invoiceRef= lv.getItemAtPosition(i).toString().substring(startIndex + 1, endIndex);

                databaseHelper.getCustomerInfoById(uid);
                databaseHelper.getTransactionByTransNo(invoiceRef,uid,InvoicesListActivity.this);




            }
        });

    }



    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        switch(requestCode){
            case 1:
                if (grantResults[0]==PackageManager.PERMISSION_GRANTED) {
                 // permision granted


                }
                else
                {
                    // Permission Denied
                    Toast.makeText(this, "WRITE_EXTERNAL Permission Denied", Toast.LENGTH_SHORT).show();
                    finish();
                }

        }

    }
}