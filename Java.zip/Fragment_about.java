package tecno.khaledtar.com.contolk;


import android.content.Intent;
import android.support.v4.app.Fragment;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.Toast;


/**
 * A simple {@link Fragment} subclass.
 */
public class Fragment_about extends Fragment {
    public Fragment_about() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

 View view= inflater.inflate(R.layout.fragment_fragment_about, container, false);

     //   VideoView mVideoView = new VideoView(getActivity());
     //  getActivity().setContentView(mVideoView);
     //   mVideoView.setVideoURI(Uri.parse("android.resource://" +getActivity().getPackageName() + "/" + R.raw.tmediator));
     //   mVideoView.start();

        Button contact=(Button) view.findViewById(R.id.about_contactUs_button) ;
        contact.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String[] TO = {"jacob_saxtoft@hotmail.com"};
                String[] CC = {"khaledtar.tecno@gmail.com"};
                Intent emailIntent = new Intent(Intent.ACTION_SEND);
                emailIntent.setData(Uri.parse("mailto:"));
                emailIntent.setType("text/plain");


                emailIntent.putExtra(Intent.EXTRA_EMAIL, TO);
                emailIntent.putExtra(Intent.EXTRA_CC, CC);
                emailIntent.putExtra(Intent.EXTRA_SUBJECT, "Your subject");
                emailIntent.putExtra(Intent.EXTRA_TEXT,"Sent from user ref: "+((ConTolk)getActivity().getApplication()).getFirebaseUserAuthenticateId());


                try {
                    startActivity(Intent.createChooser(emailIntent, "Send mail..."));
                } catch (android.content.ActivityNotFoundException ex) {
                    Toast.makeText(getActivity(),
                            "There is no email client installed.", Toast.LENGTH_SHORT).show();
                }

            }
        });
        return view;
    }





}
