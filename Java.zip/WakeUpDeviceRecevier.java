package tecno.khaledtar.com.contolk;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.content.SharedPreferences;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.IBinder;
import android.util.Log;

import com.sinch.android.rtc.SinchError;

import tecno.khaledtar.com.contolk.Snich.BaseActivity;
import tecno.khaledtar.com.contolk.Snich.SinchService;
import tecno.khaledtar.com.contolk.Translators.TranslatorOperationActivity;

import static android.content.Context.BIND_AUTO_CREATE;
import static tecno.khaledtar.com.contolk.Snich.BaseActivity.*;

/**
 * Created by Khaled on 17-Mar-18.
 */

public class WakeUpDeviceRecevier extends BroadcastReceiver  {

    AlarmManager alarmManager;

    @Override
    public void onReceive(Context context, Intent intent) {



        ConnectivityManager conn =  (ConnectivityManager)context.getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = conn.getActiveNetworkInfo();


            if (networkInfo != null && networkInfo.getDetailedState() == NetworkInfo.DetailedState.CONNECTED) {

                Log.i(WakeUpDeviceRecevier.class.getSimpleName(), "Service Stops! Oooooooooooooppppssssss!!!!");
                context.startService(new Intent(context, SinchService.class));
               String userName=intent.getExtras().getString("email_key");
                TranslatorOperationActivity.getSinchServiceInterface().stopClient();
               TranslatorOperationActivity.getSinchServiceInterface().startClient(userName);


            }

      /*      PersistedSettings userSettings=new PersistedSettings(context);

            String userName=userSettings.getUsername();

            if (!(BaseActivity.getSinchServiceInterface().isStarted()))
                BaseActivity.getSinchServiceInterface().startClient(userName);  */





    }



    private ServiceConnection mConnection = new ServiceConnection() {



        @Override
        public void onServiceConnected(ComponentName componentName, IBinder iBinder) {
            if (SinchService.class.getName().equals(componentName.getClassName())) {
                BaseActivity.mSinchServiceInterface = (SinchService.SinchServiceInterface) iBinder;


            }
        }

        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            if (SinchService.class.getName().equals(componentName.getClassName())) {
                BaseActivity.mSinchServiceInterface = null;

            }
        }};


    private  class PersistedSettings {

        private SharedPreferences mStore;

        private static final String PREF_KEY = "Sinch";

        public PersistedSettings(Context context) {
            mStore = context.getSharedPreferences(PREF_KEY, MODE_PRIVATE);
        }

        public  String getUsername() {
            return mStore.getString("Username", "");
        }

        public void setUsername(String username) {
            SharedPreferences.Editor editor = mStore.edit();
            editor.putString("Username", username);
            editor.commit();
        }
    }
}