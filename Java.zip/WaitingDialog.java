package tecno.khaledtar.com.contolk;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import tecno.khaledtar.com.contolk.Customers.RegularCallActivity;

import static java.lang.Thread.sleep;

public class WaitingDialog extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_waiting_dialog);

        try {
            sleep(5000);

      finish();

        } catch (InterruptedException e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void onStop() {
        super.onStop();
        Intent i = new Intent(this,RegularCallActivity.class);
        i.putExtra("tid_key",getIntent().getExtras().getString("tid_key"));
        i.putExtra("rating_key",getIntent().getExtras().getString("rating_key"));
        i.putExtra("phoneNo_key",getIntent().getExtras().getString("phoneNo_key"));
        i.putExtra("totalHours_key",getIntent().getExtras().getString("totalHours_key"));
        i.putExtra("balance_key",getIntent().getExtras().getString("balance_key"));
        startActivity(i);
    }
}
