package tecno.khaledtar.com.contolk;

import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.app.Application;
import android.app.PendingIntent;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.PowerManager;
import android.os.SystemClock;
import android.support.annotation.NonNull;
import android.support.multidex.MultiDex;
import android.support.v4.app.FragmentActivity;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

//import com.delaroystudios.firebaselogin.Helper.Helper;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.ValueEventListener;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;

import tecno.khaledtar.com.contolk.Customers.CustomerOperationsActivity;
import tecno.khaledtar.com.contolk.Customers.EditCustomerProfileActivity;
import tecno.khaledtar.com.contolk.Customers.RegularCallActivity;
import tecno.khaledtar.com.contolk.Customers.SelectedTranslatorActivity;
import tecno.khaledtar.com.contolk.Firebase.FirebaseDatabaseHelper;
import tecno.khaledtar.com.contolk.Helper.Helper;
import tecno.khaledtar.com.contolk.Snich.SinchService;
import tecno.khaledtar.com.contolk.Translators.EditTranslatorProfileActivity;
import tecno.khaledtar.com.contolk.Translators.TranslatorOperationActivity;

public class ConTolk extends Application {

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }

    private static final String TAG = ConTolk.class.getSimpleName();
  public String userType="";
String uid;


    public FirebaseAuth firebaseAuth;

    public FirebaseAuth.AuthStateListener mAuthListener;

    public FirebaseAuth getFirebaseAuth(){
        return firebaseAuth = FirebaseAuth.getInstance();
    }

    public String getFirebaseUserAuthenticateId() {
        String userId = null;
        if(firebaseAuth.getCurrentUser() != null){
            userId = firebaseAuth.getCurrentUser().getUid();
        }
        return userId;
    }


    public void checkUserLogin(final Context context){
        if(getFirebaseAuth().getCurrentUser() != null){

userType=readFrom_sharedprefernce(context,"userType_key");
            if (userType.equals("User"))
            {
                String firstTimeLogIn=readFrom_sharedprefernce(context,"firstTimeLogIn");
                switch (firstTimeLogIn){

                    case "true":{

                        Intent editProfileIntent = new Intent(context, EditCustomerProfileActivity.class);
                        context.startActivity(editProfileIntent);
                        ((Activity) context).finish();
                        break;
                    }
                    case "false":{

                        Intent profileIntent = new Intent(context, CustomerOperationsActivity.class);
                        context.startActivity(profileIntent);
                      ((Activity) context).finish();

                        break;
                    }
                }

            }

                else

                    if (userType.equals("Translator")) {

                        String firstTimeLogIn = readFrom_sharedprefernce(context, "firstTimeLogIn");
                        switch (firstTimeLogIn) {

                            case "true": {

                                Intent editProfileIntent = new Intent(context, EditTranslatorProfileActivity.class);

                               context.startActivity(editProfileIntent);

                                ((Activity) context).finish();
                                break;
                            }
                            case "false": {

                                Intent profileIntent = new Intent(context, TranslatorOperationActivity.class);
                                context.startActivity(profileIntent);
                               ((Activity) context).finish();

                                break;
                            }
                        }


                    }
        }



    }




    public void createNewUser(final Context context, final String email, final String password, String who, final String language,final String experiance, final TextView errorMessage){
        userType=who;
        firebaseAuth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener((Activity) context, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                Log.d(TAG, "createUserWithEmail:onComplete:" + task.isSuccessful());
                if (!task.isSuccessful()) {
                    errorMessage.setText("Failed to sign up.");
                } else
                    {

                   //     updateUserStatus("UnDetermend");
                        String id=getFirebaseAuth().getCurrentUser().getUid();
                        String profileEmail=getFirebaseAuth().getCurrentUser().getEmail().toString();
                         switch(userType){
                        case "User":{

                            Map<String, Object> userProfile = new HashMap<String, Object>();
                            userProfile.put("uId",id);
                            userProfile.put("Email",profileEmail);
                            userProfile.put("SubscriptionDate",Helper.getCurrentDateTime());
                            userProfile.put("Balance","0");
                            userProfile.put("TotalTime","0");

                            FirebaseDatabaseHelper firebaseDatabaseHelper = new FirebaseDatabaseHelper();
                            firebaseDatabaseHelper.createUserInFirebaseDatabase(id, userProfile);

                            break;
                        }

                            case "Translator":{

                                Map<String, Object> translatorProfile = new HashMap<String, Object>();
                                translatorProfile.put("uId",id);
                                translatorProfile.put("Email",profileEmail);
                                translatorProfile.put("status","Unavailable");
                                translatorProfile.put("language",language);
                                translatorProfile.put("SubscriptionDate",Helper.getCurrentDateTime());
                                translatorProfile.put("totalWorkingTime","0");
                                translatorProfile.put("Balance","0");
                                translatorProfile.put("Rating","0");
                                translatorProfile.put("YearsExperiance",experiance);

                                FirebaseDatabaseHelper firebaseDatabaseHelper = new FirebaseDatabaseHelper();
                                firebaseDatabaseHelper.createTranslatorInFirebaseDatabase(id, translatorProfile);

                                break;
                            }
                         }


                        Toast.makeText(ConTolk.this,"sign up successfully",Toast.LENGTH_LONG).show();
                        errorMessage.setText("");




                    }

            }
        });
    }

    public void loginAUser(final Context context, final ProgressBar progressBar, final String email, String password, final TextView errorMessage){

        firebaseAuth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener((Activity)context, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        progressBar.setVisibility(View.GONE);
                        if (!task.isSuccessful()) {
                            errorMessage.setText("Failed to login");
                        }else {

                            String firstTimeLogIn=readFrom_sharedprefernce(context,"firstTimeLogIn");
                            if(firstTimeLogIn==null)
                            {
                               // ((Activity) context).finish();
                               saveUserAccessInfo_sharedprefernce(context,"firstTimeLogIn","true");
                                }

                            uid=getFirebaseUserAuthenticateId() ;
                            saveUserAccessInfo_sharedprefernce(context,"uid",uid);
                           // saveUserAccessInfo_sharedprefernce(context,"email_key",email);

                            checkUserType(context);




                        }
                    }
                });


     /*   firebaseAuth.addAuthStateListener(new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {

                if(firebaseAuth.getCurrentUser() != null){
                FirebaseDatabaseHelper firebaseDatabaseHelper = new FirebaseDatabaseHelper();
                firebaseDatabaseHelper.databaseReference.child("Users Status").child(firebaseAuth.getCurrentUser().getUid()).child("Status").addListenerForSingleValueEvent(new ValueEventListener() {

                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {

                        if (dataSnapshot.getValue(String.class).equals("LoggedIn")) {
                            Toast.makeText(ConTolk.this, "This user has already logged in", Toast.LENGTH_SHORT).show();
                            ((Activity) context).finish();
                            Intent mainIntent = new Intent(context, MainActivity.class);
                       context.startActivity(mainIntent);

                        }
                        else
                            if(getFirebaseAuth().getCurrentUser() != null)
                            updateUserStatus("LoggedIn");

                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
            }

        }
        });  */

    }

    public void saveUserAccessInfo_sharedprefernce(Context context,String key,String value) {
        SharedPreferences sharedPref =context.getSharedPreferences(getPackageName()+"userInfo",Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPref.edit();

        editor.putString(key, value);
        editor.commit();



    }


    public  String readFrom_sharedprefernce(Context context,String key) {
        SharedPreferences sharedPref =context.getSharedPreferences(getPackageName()+"userInfo",Context.MODE_PRIVATE);
        String userType = sharedPref.getString(key, null);
        return userType;
    }



    public void checkInternetConnection(final FragmentActivity activity) {

        if(!Helper.checkInternetConnection(activity)){
            AlertDialog.Builder alert = new AlertDialog.Builder(activity);
            alert.setTitle("No internet connection!, please check your internet setting")
                    .setIcon(R.drawable.ic_info_blue_a400_24dp)
                    .setNegativeButton("OK",new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int whichButton) {
                            activity.finish();
                        }
                    });
            alert.show();
        }
    }

  /* public void updateUserStatus(String status){

        Map<String, Object> userProfile = new HashMap<String, Object>();
        userProfile.put("Status",status);
        userProfile.put("DateTime",formattedDate);
        FirebaseDatabaseHelper firebaseDatabaseHelper = new FirebaseDatabaseHelper();
        firebaseDatabaseHelper.updateUserStatus(firebaseAuth.getUid(), userProfile);


    }  */



    public void checkUserType(final Context context) {

        uid = getFirebaseUserAuthenticateId();

        FirebaseDatabaseHelper firebaseDatabaseHelper = new FirebaseDatabaseHelper();
        firebaseDatabaseHelper.getDatabaseReference().addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {

                if (dataSnapshot.child("Users").hasChild(uid)){
                    userType = "User";
                    saveUserAccessInfo_sharedprefernce(context,"userType_key",userType);
                    goToUserPage(context);
                }

                else if (dataSnapshot.child("Translators").hasChild(uid)){
                    userType = "Translator";
                    saveUserAccessInfo_sharedprefernce(context,"userType_key",userType);
                    saveUserAccessInfo_sharedprefernce(context,"language_key",dataSnapshot.child("Translators").child(uid).child("language").getValue(String.class));
                goToTranslatorPage(context);}
                else{
                    Toast.makeText(context,"Username is not exist, please contact with support",Toast.LENGTH_LONG).show();
                    ((Activity) context).finish();
                }


              //  if ((context instanceof MainActivity) || (context instanceof WelcomeActivity) && (getFirebaseAuth().getCurrentUser() != null))
               //     checkUserLogin(context);


            }


            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });







    }

    private void goToTranslatorPage(Context context) {

            String firstTimeLogIn = readFrom_sharedprefernce(context, "firstTimeLogIn");
            switch (firstTimeLogIn) {

                case "true": {

                    Intent editProfileIntent = new Intent(context, EditTranslatorProfileActivity.class);
                    context.startActivity(editProfileIntent);
                    ((Activity) context).finish();
                    break;
                }
                case "false": {

                    Intent profileIntent = new Intent(context, TranslatorOperationActivity.class);
                    context.startActivity(profileIntent);
                    ((Activity) context).finish();
                    break;
                }
            }



    }

    private void goToUserPage(Context context) {
        String firstTimeLogIn=readFrom_sharedprefernce(context,"firstTimeLogIn");
        switch (firstTimeLogIn){

            case "true":{

                Intent editProfileIntent = new Intent(context, EditCustomerProfileActivity.class);
                context.startActivity(editProfileIntent);
                ((Activity) context).finish();
                break;
            }
            case "false":{

                Intent profileIntent = new Intent(context, CustomerOperationsActivity.class);
                context.startActivity(profileIntent);
                ((Activity) context).finish();

                break;
            }
        }


    }


    public  void wakeUpDevice() {
        PowerManager pm = (PowerManager) getBaseContext().getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock cpuWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, SinchService.class.getSimpleName());
        cpuWakeLock.acquire();


    }

    public  void relaseDevice() {
        PowerManager pm = (PowerManager) getBaseContext().getApplicationContext().getSystemService(Context.POWER_SERVICE);
        PowerManager.WakeLock cpuWakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, SinchService.class.getSimpleName());
        cpuWakeLock.release();
    }


    public  void setAlarmForWakeupDevice() {
AlarmManager alarmManager;
        Intent i = new Intent(this, WakeUpDeviceRecevier.class);
       PendingIntent pIntent = PendingIntent.getBroadcast(this, 0, i, 0);

        alarmManager = (AlarmManager)this.getSystemService(this.ALARM_SERVICE);
     alarmManager.set(AlarmManager.RTC_WAKEUP,System.currentTimeMillis(),pIntent);
    }


        public void checkIfUserAlive(final Context context){
            FirebaseUser user=getFirebaseAuth().getCurrentUser();

        user.reload().addOnFailureListener(new OnFailureListener() {

            @Override
            public void onFailure(@NonNull Exception e) {

                final AlertDialog.Builder alert = new AlertDialog.Builder(context);
                alert.setTitle("user doesn't exist anymore")
                        .setCancelable(false)
                        .setPositiveButton("OK",new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                ((Activity)context).finish();
                                System.exit(0);
                            }
                        });

                alert.show();



            }
        });
    }



}
