package tecno.khaledtar.com.contolk;

import android.Manifest;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.v4.app.ActivityCompat;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.crashlytics.android.Crashlytics;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthInvalidUserException;

import java.io.File;

import io.fabric.sdk.android.Fabric;
import tecno.khaledtar.com.contolk.Customers.SelectedTranslatorActivity;
import tecno.khaledtar.com.contolk.Helper.Helper;

/**
 * An example full-screen activity that shows and hides the system UI (i.e.
 * status bar and navigation/system bar) with user interaction.
 */
public class WelcomeActivity extends AppCompatActivity {
    /**
     * Whether or not the system UI should be auto-hidden after
     * {@link #AUTO_HIDE_DELAY_MILLIS} milliseconds.
     */
    private static final boolean AUTO_HIDE = true;

    /**
     * If {@link #AUTO_HIDE} is set, the number of milliseconds to wait after
     * user interaction before hiding the system UI.
     */
    private static final int AUTO_HIDE_DELAY_MILLIS = 3000;

    /**
     * Some older devices needs a small delay between UI widget updates
     * and a change of the status and navigation bar.
     */
    private static final int UI_ANIMATION_DELAY = 300;
    private final Handler mHideHandler = new Handler();
    private View mContentView;
    private final Runnable mHidePart2Runnable = new Runnable() {
        @SuppressLint("InlinedApi")
        @Override
        public void run() {
            // Delayed removal of status and navigation bar

            // Note that some of these constants are new as of API 16 (Jelly Bean)
            // and API 19 (KitKat). It is safe to use them, as they are inlined
            // at compile-time and do nothing on earlier devices.
            mContentView.setSystemUiVisibility(View.SYSTEM_UI_FLAG_LOW_PROFILE
                    | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                    | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        }
    };
    private View mControlsView;
    private final Runnable mShowPart2Runnable = new Runnable() {
        @Override
        public void run() {

            mControlsView.setVisibility(View.VISIBLE);
        }
    };


    ProgressBar  progressBar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Fabric.with(this, new Crashlytics());

        setContentView(R.layout.activity_welcome);
        
        



        progressBar= (ProgressBar) findViewById(R.id.progressBar);
        FirebaseAuth mAuth =((ConTolk)this.getApplication()).getFirebaseAuth();
        progressBar.setVisibility(View.VISIBLE);

        ImageView logo=(ImageView)findViewById(R.id.fullscreen_content) ;
        progressBar.setVisibility(View.VISIBLE);

        String firstTimeLogIn=((ConTolk)this.getApplication()).readFrom_sharedprefernce(this,"firstTimeLogIn");

        if ( ContextCompat.checkSelfPermission( this, Manifest.permission.INTERNET ) != PackageManager.PERMISSION_GRANTED )
            ActivityCompat.requestPermissions(this, new String[]{android.Manifest.permission.INTERNET}, 0);

     //   isLanchedBefore();





        //start animi
        Animation animation = new AlphaAnimation(1, 0);
        animation.setDuration(1000);
        animation.setInterpolator(new LinearInterpolator());
        animation.setRepeatCount(Animation.INFINITE);
        animation.setRepeatMode(Animation.REVERSE);
        logo.startAnimation(animation);





if (!Helper.checkInternetConnection(this)){
    Toast.makeText(this,"Please check the internet connection",Toast.LENGTH_LONG).show();

    return;
        }


        if ( firstTimeLogIn ==null && mAuth.getCurrentUser()!=null)
        {
            ((ConTolk)this.getApplication()).getFirebaseAuth().signOut();

        }


        if (mAuth.getCurrentUser()!=null ){
            ((ConTolk)this.getApplication()).checkUserLogin(this);

        }
        else
        {
            Intent logInIntent=new Intent(this,MainActivity.class);
            startActivity(logInIntent);
            finish();
        }



    }

    private boolean isLanchedBefore() {
        boolean lanchedBefore=false;
        File f = new File(Environment.getExternalStorageDirectory() + "/ConTolk");
        if(f.isDirectory()) {
            lanchedBefore=true;

        }else
        { lanchedBefore=false;
            f.mkdirs();
        }

        return lanchedBefore;
    }


    @Override
    protected void onStop() {
        super.onStop();
        progressBar.setVisibility(View.GONE);
    }

    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {

        switch (requestCode) {
            case 0: {

                if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                //    Toast.makeText(this, "You may now place a call", Toast.LENGTH_LONG).show();


                } else {
                    Toast.makeText(this, "This application needs permission to use internet connection to function properly.", Toast
                            .LENGTH_LONG).show();
                    finish();
                }
            }






        }


    }
}
