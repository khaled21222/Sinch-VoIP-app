package tecno.khaledtar.com.contolk.Firebase;


import com.google.firebase.database.Exclude;
import com.google.firebase.database.PropertyName;

import tecno.khaledtar.com.contolk.Helper.Users;

public class FirebaseCustomerEntity extends Users {

    @PropertyName("CVRnr")
    public String CVRnr ;
    @PropertyName("EANnr")
    public String EANnr;
    @PropertyName("Balance")
    public String balance;
    @PropertyName("CompanyName")
    public String companyName;
    @PropertyName("TotalTime")
    public String totalTime;


    public FirebaseCustomerEntity(){
    }








    @Exclude
    public String getCustomeCVR() {return CVRnr;}
    @Exclude
    public String getBalance() {return balance;}
    @Exclude
    public String getCompanyName() {
        return companyName;
    }
    @Exclude
    public String getCompanyEANno() {
        return EANnr;
    }

    @Exclude
    public String getTotalTime() {
        return totalTime;
    }

    @Exclude
    public void setBalance(String balance){this.balance=balance;}

    @Exclude
    public void setCustomeCVR(String CVR) {
        this.CVRnr = CVR;
    }
    @Exclude
    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }
    @Exclude
    public void setCompanyEANno(String companyEANno) {
        this.EANnr = companyEANno;
    }

    @Exclude
    public void setTotalTime(String totaltime) {
        this.totalTime = totaltime;
    }
}
