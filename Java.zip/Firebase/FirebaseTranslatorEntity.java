package tecno.khaledtar.com.contolk.Firebase;


import com.google.firebase.database.Exclude;
import com.google.firebase.database.PropertyName;

import tecno.khaledtar.com.contolk.Helper.Users;

public class FirebaseTranslatorEntity extends Users {



    @PropertyName("language")
    public String language;
    @PropertyName("status")
    public String status;

    @PropertyName("language_status")
    public String language_status;

    @PropertyName("Rating")
    public String rating;

    @PropertyName("totalWorkingTime")
    public String totalWorkingTime;

    @PropertyName("Profile")
    public String profile;

    @PropertyName("Gender")
    public String gender;

    @PropertyName("YearsExperiance")
    public String yearsExperiance;







    public FirebaseTranslatorEntity(){
    }

 /*   public FirebaseTranslatorEntity(String uId, String email, String name, String address, String phone,String language,String status) {
        this.uId = uId;
        this.emaiAddress = email;
        this.fullName = name;
        this.address = address;
        this.phone = phone;
        this.language = language;
        this.status=status;



    }   */





    @Exclude
    public String getStatus() {return this.status;}

    @Exclude
    public String getYearsExperiance() {return this.yearsExperiance;}

    @Exclude
    public String getGender() {return this.gender;}


    @Exclude
    public String getProfile() {return this.profile;}

    @Exclude
    public String getLanguage() {
        return this.language;
    }

    @Exclude
    public String getLanguage_status() {return this.language_status;}

    @Exclude
    public String getTotalWorkingTime() {return this.totalWorkingTime;}

    @Exclude
    public String getRatings() {return this.rating;}


    @Exclude
    public void  setTotalWorkingTime(String totalWorkingTime){this.totalWorkingTime=totalWorkingTime;}
    @Exclude
    public void  setLanguage(String totalWorkingTime){this.language=totalWorkingTime;}
    @Exclude
    public void  setStatus(String status){this.status=status;}

    @Exclude
    public void  setGender(String status){this.gender=gender;}

    @Exclude
    public void  setProfile(String profile){this.profile=profile;}

    @Exclude
    public void  setLanguage_status(String language_status){this.language_status=language_status;}

    @Exclude
    public void  setYearsExperiance(String yearsExperiance){this.yearsExperiance=yearsExperiance;}

    @Exclude
    public void  setRatings(String customerRating){this.rating=customerRating;}
}
