package tecno.khaledtar.com.contolk.Firebase;

/**
 * Created by Khaled on 16-Dec-17.
 */

public class FirebaseTransactionEntity {
    protected String  trans_Id;
    protected  String  c_Id;
    protected String t_Id;
    protected  String dateandTime;
    protected  String callDuration;
    protected String  pricePerMinute;
    protected String customerRating;
    protected String customerFeedback;
    protected String deservedAmount;

    public FirebaseTransactionEntity(){}

    public  FirebaseTransactionEntity(String  trans_Id,
            String  c_Id,
             String t_Id,
              String dateandTime,
              String callDuration,
             String  pricePerMinute,
             String deservedAmount)
    {
        this.trans_Id=trans_Id;
        this.c_Id=c_Id;
        this.t_Id=t_Id;
        this.dateandTime=dateandTime;
        this.callDuration=callDuration;
        this.pricePerMinute=pricePerMinute;
        this.deservedAmount=deservedAmount;
    }


    public String getTrans_Id() {
        return trans_Id;
    }

    public String getC_Id() {
        return c_Id;
    }

    public String getCallDuration() {
        return callDuration;
    }

    public String getDateandTime() {
        return dateandTime;
    }

    public String getDeservedAmount() {
        return deservedAmount;
    }

    public String getPricePerMinute() {
        return pricePerMinute;
    }

    public String getT_Id() {
        return t_Id;
    }

    public String getCustomerRating() {
        return customerRating;
    }
    public String getCustomerFeedback() {
        return customerFeedback;
    }



    public void setC_Id_Id(String c_Id){
        this.c_Id=c_Id;
    }
    public void setT_Id(String t_Id){
        this.t_Id=t_Id;
    }

    public void setdateandTime(String dateandTime){
        this.dateandTime=dateandTime;
    }

    public void setcallDuration(String callDuration){
        this.callDuration=callDuration;
    }

    public void setpricePerMinute(String pricePerMinute){
        this.pricePerMinute=pricePerMinute;
    }

    public void setDeservedAmount(String deservedAmount){
        this.deservedAmount=deservedAmount;
    }
    public void setCustomerRating(String rating){
        this.customerRating=rating;
    }
    public void setCustomerFeedback(String feedback){
        this.customerFeedback=feedback;
    }
}
