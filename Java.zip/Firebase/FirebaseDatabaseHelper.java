package tecno.khaledtar.com.contolk.Firebase;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

//import com.delaroystudios.firebaselogin.Adapters.RecyclerViewAdapterUser;
//import com.delaroystudios.firebaselogin.Helper.Helper;
//import com.delaroystudios.firebaselogin.CustomerProfile;
import com.firebase.client.FirebaseError;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import tecno.khaledtar.com.contolk.Adapters.FirebaseViewHolder;
import tecno.khaledtar.com.contolk.Adapters.RecyclerViewAdapterTranslator;
import tecno.khaledtar.com.contolk.Adapters.RecyclerViewAdapterUser;
import tecno.khaledtar.com.contolk.Adapters.RecyclerView_dAdapter;
import tecno.khaledtar.com.contolk.Customers.CustomerProfile;
import tecno.khaledtar.com.contolk.Helper.Helper;
import tecno.khaledtar.com.contolk.List_Item;
import tecno.khaledtar.com.contolk.List_Item_of_aviliable_translators;
import tecno.khaledtar.com.contolk.PrintReport;
import tecno.khaledtar.com.contolk.R;
import tecno.khaledtar.com.contolk.Translators.TranslatorProfile;

public class FirebaseDatabaseHelper {
    public DatabaseReference databaseReference,databaseReference1,databaseReference2, databaseReference3,databaseReference4,databaseReference5;
    public List<List_Item_of_aviliable_translators> listItems;

    public FirebaseTranslatorEntity translatorInfo;
    public FirebaseCustomerEntity customerInfo;
   public  FirebaseTransactionEntity transactionInfo;
   public Query query;
   RecyclerView_dAdapter adapter;




    public FirebaseDatabaseHelper(){
        databaseReference= FirebaseDatabase.getInstance().getReference();
        databaseReference1 = FirebaseDatabase.getInstance().getReference("Users");
        databaseReference2 = FirebaseDatabase.getInstance().getReference("Translators");
        databaseReference3 = FirebaseDatabase.getInstance().getReference("Transactions");
        databaseReference4 = FirebaseDatabase.getInstance().getReference("Available Translators");
        databaseReference5 = FirebaseDatabase.getInstance().getReference("Customers FeedBack");

        translatorInfo=new FirebaseTranslatorEntity();
        customerInfo =new FirebaseCustomerEntity();
        transactionInfo=new FirebaseTransactionEntity();

    }

    public DatabaseReference getDatabaseReference(){

        return databaseReference;
    }
    public DatabaseReference getDatabaseReference1(){

        return databaseReference1;
    }
    public DatabaseReference getDatabaseReference2(){

        return databaseReference2;
    }

    public void createUserInFirebaseDatabase(String userId,  Map<String, Object> firebasuserinfo){

        databaseReference.child("Users").child(userId).updateChildren(firebasuserinfo);
    }

    public void createTranslatorInFirebaseDatabase(String userId, Map<String, Object> firebasuserinfo){

        databaseReference.child("Translators").child(userId).updateChildren(firebasuserinfo);
    }


    public void updateUserStatus(String userId, Map<String, Object> userProfile) {

        databaseReference.child("Users Status").child(userId).updateChildren(userProfile);
    }



    public void updateTranslatorStatus(String userId,String language,String updatedStatus){
        Map<String, Object> translator = new HashMap<String, Object>();
       translator.put( "status",updatedStatus);
        translator.put( "language_status",language+"_"+updatedStatus);
        databaseReference2.child(userId).updateChildren(translator);
    }

    public void isUserKeyExist(final String uid, final Context context, final RecyclerView recyclerView){
        databaseReference.child("Users").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {

                    if (dataSnapshot.getKey().equals(uid)) {
                        customerInfo=dataSnapshot.getValue(FirebaseCustomerEntity.class);
                        List<CustomerProfile> userData = adapterSourceData(dataSnapshot, uid);
                        RecyclerViewAdapterUser recyclerViewAdapterUser = new RecyclerViewAdapterUser((Activity)context, userData);
                        recyclerView.setAdapter(recyclerViewAdapterUser);
                        recyclerView.setVerticalScrollBarEnabled(true);



                    }


                }


            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {

                    if (dataSnapshot.getKey().equals(uid)) {
                        List<CustomerProfile> userData = adapterSourceData(dataSnapshot, uid);
                        RecyclerViewAdapterUser recyclerViewAdapterUser = new RecyclerViewAdapterUser((Activity)context, userData);
                        recyclerView.setAdapter(recyclerViewAdapterUser);
                        recyclerView.setVerticalScrollBarEnabled(true);

                    }


            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }

 public void isTranslatorKeyExist(final String uid, final Context context, final RecyclerView recyclerView){


        databaseReference.child("Translators").addChildEventListener(new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                if (dataSnapshot.getKey().equals(uid)) {
                List<TranslatorProfile> translatorData = adapterSourceData2(dataSnapshot, uid);
                RecyclerViewAdapterTranslator recyclerViewAdapterTranslator = new RecyclerViewAdapterTranslator((Activity)context, translatorData);
                recyclerView.setAdapter(recyclerViewAdapterTranslator);
                    recyclerView.setVerticalScrollBarEnabled(true);


                }
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
                if (dataSnapshot.getKey().equals(uid)) {
                List<TranslatorProfile> translatorData = adapterSourceData2(dataSnapshot, uid);
                RecyclerViewAdapterTranslator recyclerViewAdapterTranslator = new RecyclerViewAdapterTranslator((Activity)context, translatorData);
                recyclerView.setAdapter(recyclerViewAdapterTranslator);
                    recyclerView.setVerticalScrollBarEnabled(true);
                }
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {

            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {

            }

            @Override
            public void onCancelled(DatabaseError databaseError) {

            }
        });
    }


    private List<CustomerProfile> adapterSourceData(DataSnapshot dataSnapshot, String uId){
        List<CustomerProfile> allUserData = new ArrayList<CustomerProfile>();
        if(dataSnapshot.getKey().equals(uId)){
            FirebaseCustomerEntity userInformation = dataSnapshot.getValue(FirebaseCustomerEntity.class);

            allUserData.add(new CustomerProfile(Helper.COMPANY_NAME, userInformation.getCompanyName()));
            allUserData.add(new CustomerProfile(Helper.CVR, userInformation.getCustomeCVR()));

            allUserData.add(new CustomerProfile(Helper.ADDRESS, userInformation.getAddress()));
            allUserData.add(new CustomerProfile(Helper.CITY, userInformation.getCity()));
            allUserData.add(new CustomerProfile(Helper.POSTnr, userInformation.getPostnr()));

            allUserData.add(new CustomerProfile(Helper.NAME, userInformation.getName()));
            allUserData.add(new CustomerProfile(Helper.EMAIL, userInformation.getEmail()));
            allUserData.add(new CustomerProfile(Helper.PHONE_NUMBER, userInformation.getPhone()));

            allUserData.add(new CustomerProfile(Helper.EAN, userInformation.getCompanyEANno()));
            allUserData.add(new CustomerProfile(Helper.Balance,String.format( " %.2f",Double.parseDouble(userInformation.getBalance())) +" DDK" )) ;
            allUserData.add(new CustomerProfile(Helper.TOTALTIME,String.format( " %.2f",Double.parseDouble(userInformation.getTotalTime())) + " Minutes" ));


        }
        return allUserData;
    }

    private List<TranslatorProfile> adapterSourceData2(DataSnapshot dataSnapshot, String uId){
        List<TranslatorProfile> allTranslatorData = new ArrayList<TranslatorProfile>();
        if(dataSnapshot.getKey().equals(uId)){
            FirebaseTranslatorEntity translatorInformation = dataSnapshot.getValue(FirebaseTranslatorEntity.class);
            allTranslatorData.add(new TranslatorProfile(Helper.NAME, translatorInformation.getName()));
            allTranslatorData.add(new TranslatorProfile(Helper.EMAIL, translatorInformation.getEmail()));
            allTranslatorData.add(new TranslatorProfile(Helper.PHONE_NUMBER, translatorInformation.getPhone()));
            allTranslatorData.add(new TranslatorProfile(Helper.ADDRESS, translatorInformation.getAddress()));
            allTranslatorData.add(new TranslatorProfile(Helper.LANGUAGE, translatorInformation.getLanguage()));
            allTranslatorData.add(new TranslatorProfile(Helper.STATUS, translatorInformation.getStatus()));
            allTranslatorData.add(new TranslatorProfile(Helper.TOTALWORKINGHOURS, String.format( " %.2f",Double.parseDouble(translatorInformation.getTotalWorkingTime()))+ " Minutes"));
            allTranslatorData.add(new TranslatorProfile(Helper.Balance,String.format( " %.2f",Double.parseDouble(translatorInformation.getBalance()))+" DDK"));
        }
        return allTranslatorData;
    }





    public void availableTranslators(final String language,final String userEmail, final Context context,final RecyclerView recyclerView,final ProgressDialog mProgressDialog) {
      mProgressDialog.show();
         final List<List_Item> listItems=new  ArrayList();



        //
        query = databaseReference2.orderByChild("language_status").equalTo(language+"_Available");
        query.addValueEventListener(new ValueEventListener() {
                                                 @Override
                                                 public void onDataChange(DataSnapshot dataSnapshot) {
                                                     Iterable<DataSnapshot> Children = dataSnapshot.getChildren();

                                                     for ( DataSnapshot datashot:Children) {
                                                         FirebaseTranslatorEntity translatorEntity=datashot.getValue(FirebaseTranslatorEntity.class) ;
                                                         listItems.add(new List_Item(translatorEntity));

                                                     }



                                                     FirebaseRecyclerAdapter<FirebaseTranslatorEntity, FirebaseViewHolder> adapter = new FirebaseRecyclerAdapter<FirebaseTranslatorEntity, FirebaseViewHolder>(
                                                             FirebaseTranslatorEntity.class, R.layout.row_item, FirebaseViewHolder.class, query){

                                                         @Override
                                                         protected void populateViewHolder(FirebaseViewHolder viewHolder, FirebaseTranslatorEntity model, int position) {

                                                             viewHolder.bindview(userEmail,model,mProgressDialog);

                                                         }};

                                                     recyclerView.setAdapter(adapter);
                                                     //   adapter  = new RecyclerView_dAdapter(listItems, context,userEmail,mProgressDialog);



                                                 }

                                                 @Override
                                                 public void onCancelled(DatabaseError databaseError) {

                                                 }
                                             } );



        //

/*


        adapter= new RecyclerViewAdapterTranslator<FirebaseTranslatorEntity,FirebaseViewHolder>(FirebaseTranslatorEntity.class,R.layout.row_item, FirebaseViewHolder.class,translatersList) {

            @Override
            protected void populateViewHolder(FirebaseViewHolder viewHolder, FirebaseTranslatorEntity model, int position) {
                viewHolder.bindview( model);
            }

            @Override
            public void onBindViewHolder(FirebaseViewHolder viewHolder, int position) {
                super.onBindViewHolder(viewHolder, position);
                if (mProgressDialog != null && mProgressDialog.isShowing())
                    mProgressDialog.dismiss();

            }
        };

        recyclerView.setAdapter(adapter);   */



    /*

      Iterable<DataSnapshot> Children = dataSnapshot.getChildren();


                for ( DataSnapshot datashot:Children) {

                    FirebaseTranslatorEntity translatorInfo =datashot.getValue(FirebaseTranslatorEntity.class);
                    if ((translatorInfo.getStatus().equals("Available"))){


                    databaseReference4.child(language).child(translatorInfo.getuId()).setValue(translatorInfo);}
                    else
                  if ((translatorInfo.getStatus().equals("Unavailable"))||(translatorInfo.getStatus().equals("Reserved")) )
                     databaseReference4.child(language).child(translatorInfo.getuId().toString()).removeValue();


                    adapter= new FirebaseRecyclerAdapter<FirebaseTranslatorEntity,FirebaseViewHolder>(FirebaseTranslatorEntity.class,R.layout.row_item, FirebaseViewHolder.class,databaseReference4.child(language)) {

                        @Override
                        protected void populateViewHolder(FirebaseViewHolder viewHolder, FirebaseTranslatorEntity model, int position) {
                            viewHolder.bindview(model);
                        }

                        @Override
                        public void onBindViewHolder(FirebaseViewHolder viewHolder, int position) {
                            super.onBindViewHolder(viewHolder, position);
                           if (mProgressDialog != null && mProgressDialog.isShowing())
                                mProgressDialog.dismiss();

                        }
                    };

                    recyclerView.setAdapter(adapter);


                }




     */

    }
    public void addTransaction(FirebaseTransactionEntity newTransaction,String cid) {

        databaseReference3.child(cid).push().setValue(newTransaction);

    }
    public void addFeedBack(String cId,String tId,String feedback,String date){
        Map<String, Object> feedbackRecord = new HashMap<String, Object>();
        feedbackRecord.put( "cId",cId);
        feedbackRecord.put( "tId",tId);
        feedbackRecord.put( "feedback",feedback);
        feedbackRecord.put( "dateTime",date);
        databaseReference5.push().setValue(feedbackRecord);
    }



    public void getTransactionsListOfCurrentUser(String uid, String userType, final Context context, final ListView lv, final ProgressDialog progressDialog){

        final ArrayList query=new  ArrayList();


       if (userType.equals("User")){
           databaseReference3.child(uid).orderByChild("c_Id").equalTo(uid).addListenerForSingleValueEvent(new ValueEventListener() {
               @Override
               public void onDataChange(DataSnapshot dataSnapshot) {
                   
                   Iterable<DataSnapshot> Children = dataSnapshot.getChildren();

                   for ( DataSnapshot datashot:Children) {
                       FirebaseTransactionEntity transaction=datashot.getValue(FirebaseTransactionEntity.class) ;

                       query.add("Trans Ref: "+"("+datashot.getKey()+") \n"+ "Date: "+transaction.getDateandTime()+"\n"+" \n"+
                       "CLICK to view");
                   }

                   ArrayAdapter adapter = new ArrayAdapter((Activity)context, android.R.layout.simple_list_item_1,  query);
                   if(adapter.getCount() > 0){
                       progressDialog.dismiss();
                       lv.setAdapter(adapter);}
                   else adapter.clear();




               }

               @Override
               public void onCancelled(DatabaseError databaseError) {

               }


           });


       }



    }



    public void getTransactionByTransNo(final String transNo,final String cid,final Context context){

 databaseReference3.child(cid).addValueEventListener(new ValueEventListener() {
     @Override
     public void onDataChange(DataSnapshot dataSnapshot) {
         Iterable<DataSnapshot> Children = dataSnapshot.getChildren();

         for ( DataSnapshot datashot:Children) {
             if (datashot.getKey().equals(transNo)){
             FirebaseTransactionEntity transaction=datashot.getValue(FirebaseTransactionEntity.class) ;
             PrintReport.main("report",transaction,Helper.InvoiceHeader,context);

             break;}

         }
     }

     @Override
     public void onCancelled(DatabaseError databaseError) {

     }
 });

    }


    public void getCustomerInfoById(final String uid){

            databaseReference1.addValueEventListener(new ValueEventListener() {
                @Override
                public void onDataChange(DataSnapshot dataSnapshot) {

                    Iterable<DataSnapshot> Children = dataSnapshot.getChildren();

                    for ( DataSnapshot datashot:Children) {
if(datashot.getKey().equals(uid)) {
    customerInfo = datashot.getValue(FirebaseCustomerEntity.class);

    Helper.InvoiceHeader= "Customer Name: " + customerInfo.getCompanyName() + " ,CVR-nr." + customerInfo.getCustomeCVR() +" ,EAN-nr. "+
            customerInfo.getCompanyEANno()+"\n"+
            "Address: "+customerInfo.getAddress()+"\n"+
            "City: "+customerInfo.getCity()+"\n"+
            "Postnr.: "+customerInfo.getPostnr()+"\n"+

            ".............................................................................."+"\n"+
    "Contact person: "+customerInfo.getName()+"\n"+
    "Email: "+customerInfo.getEmail()+"\n"+
    "Phone: "+customerInfo.getPhone()+"\n"
            +"\n"+

            "______________________________________________________________________________";

break;}
                    }


                }

                @Override
                public void onCancelled(DatabaseError databaseError) {

                }


            });





    }



}