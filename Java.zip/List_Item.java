package tecno.khaledtar.com.contolk;

import tecno.khaledtar.com.contolk.Firebase.FirebaseTranslatorEntity;

/**
 * Created by Khaled on 05-Mar-18.
 */

public class List_Item {

    public String name;
    public int img;

    public FirebaseTranslatorEntity translator;

    public List_Item(FirebaseTranslatorEntity firebaseTranslatorEntity){
        this.translator = firebaseTranslatorEntity;
      //  this.img = img;
    }

    public FirebaseTranslatorEntity getTranslator() {
        return translator;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }
}
